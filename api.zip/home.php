<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/19/2018
 * Time: 4:22 PM
 */
require ("index.php");