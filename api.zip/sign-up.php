<?php
require('lib/config.php');
?>
<!doctype html>
<html lang="en-us">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sign Up | <?php echo $info['site-name']; ?></title>
    <meta name="description" content="<?php echo $info['descriptions']; ?>">
    <meta name="keywords" content="<?php echo $info['tags']; ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400i,600" rel="stylesheet">

    <!-- Favicon -->
    <link rel="apple-touch-icon" href="img/logo.png">
    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">

    <script type="text/javascript" src="js/turbo.js" difer></script>
    <script type="text/javascript" src="js/vue.js"></script>
    <meta name="turbolinks-cache-control" content="no-cache">
    <!-- Stylesheet -->
    <!--<link rel="stylesheet" href="css/main.css">-->
    <link rel="stylesheet" href="css/main.druplay.css">

    <!--TopProgress Bar-->
    <script type="text/javascript" src="js/topBar.js"></script>
    <link rel="stylesheet" href="css/topBar.css"/>
</head>
<body class="o-page o-page--center">
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://chrome.google.com/">upgrade your browser</a> to improve your experience and security.</p>
<![endif]-->

<div class="o-page__card">
    <div class="c-card u-mb-xsmall">
        <header class="c-card__header u-pt-large">
            <a class="c-card__icon">
                <img style="padding: 5px;" src="img/logo.png" alt="logo">
            </a>
            <h1 class="u-h3 u-text-center u-mb-zero">Sign up to Get Started</h1>
        </header>

        <form id="form" method="post" class="c-card__body" onsubmit="return submitData();">
            <div class="c-field u-mb-small">
                <label class="c-field__label" for="email">Full name</label>
                <input name="name" class="c-input" type="text" id="name" placeholder="Ordenary Ahmed">
            </div>

            <div class="c-field u-mb-small">
                <label class="c-field__label" for="email">E-mail address</label>
                <input name="email" class="c-input" type="email" id="email" placeholder="xyz@gmail.com">
            </div>

            <div class="c-field u-mb-small">
                <label class="c-field__label" for="phone">Phone no.</label>
                <input name="phone" class="c-input" type="tel" id="phone" placeholder="080xxxxxx">
            </div>

            <div class="c-field u-mb-small">
                <label class="c-field__label" for="pass1">Password</label>
                <input name="pass1" class="c-input" type="password" id="pass1" placeholder="Number, letters and symbols">
            </div>

            <div class="c-field u-mb-small">
                <label class="c-field__label" for="pass2">Confirm Password</label>
                <input name="pass2" class="c-input" type="password" id="pass2" placeholder="Confirm Password">
            </div>

            <div class="c-field u-mb-small">
                <label class="c-field__label" for="pass2">Apply Role</label>
                <select name="role" class="c-input">
                    <option value="1">Administrator</option>
                    <option value="2">Publisher</option>
                </select>
            </div>

            <div class="c-field u-mb-small">
                <label class="c-field__label" for="lkey">Authorization Key</label>
                <input v-model="eke" name="lkey" class="c-input" type="text" id="lkey" placeholder="10 Digit license key">
            </div>

            <button class="c-btn c-btn--info c-btn--fullwidth" type="submit">Sign Up</button>

        </form>
    </div>

    <div class="o-line">
        <a class="u-text-mute u-text-small" data-turbolinks-action="replace" href="sign-in" title="Login">
            <i class="fa fa-long-arrow-left u-mr-xsmall"></i> Already have an account, login instead
        </a>
    </div>

</div>
<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>
    function submitData(frm) {
        NProgress.start();
        $.ajax({type: 'POST', url: 'api?act=sign-up',data: $('#form').serialize(), success: function (data) {
            alert(data);
            NProgress.done();
        }, dataType: 'text'});
        return false;
    }
</script>
</body>
</html>