<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/23/2018
 * Time: 8:32 AM
 */
require('lib/systems.php');

switch ($_GET['exec']) {
    case 'timestamp':
        timeStamp();
        break;
    default:
        exit(0);

}

//time stamp function
function timeStamp()
{
echo time_elapsed_string((int)$_GET['data']);
}