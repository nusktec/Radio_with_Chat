<?php
require('lib/config.php');
page_identity(8, 'U-Reports');
?>
<!doctype html>
<html lang="en-us">
<?php require('header-js.php') ?>
<style>
    * {
        -webkit-user-select: none;
    }
</style>
<?php
$phone = (@$_GET['phone'] == null) ? @$_POST['phone'] : @$_GET['phone'];
$app_id = (@$_GET['app_id'] == null) ? @$_POST['app_id'] : @$_GET['app_id'];

$phone = fNumber($phone);

$db = new Db();

//read from database
$rep = $db->query("select * from `reports` INNER  JOIN `users` on `reports`.`rep_reporter`=`users`.`phone` where `reports`.`rep_id`='$app_id' and `reports`.`rep_reporter`='$phone' order by `reports`.`rep_finder` desc");

if (true) {
    ?>
    <div class="container  o-page--center u-text-center">
        <i class="fa fa-file" style="font-size: 48px"></i>
        <p class="u-color-danger">Tell us what's happening !</p>
        <br/>
        <a type="button" class="c-btn c-btn--secondary" data-toggle="modal"
           data-target="#writerep"
           class="c-btn c-btn--secondary c-btn--fullwidth"
           aria-label="Read More" href="javascript:void(0)">Write New Report</a>
    </div>
    <!-- Modal -->
    <div class="c-modal modal fade" id="writerep" tabindex="-1" role="dialog"
         aria-labelledby="writerep" aria-hidden="true" style="display: none;">
        <div class="c-modal__dialog modal-dialog" role="document">
            <div class="modal-content">
                <div class="c-card u-p-medium u-mh-auto" style="max-width:500px;">
                    <h3>Write New Report</h3>
                    <textarea class="c-input" id="txtreport" placeholder="Write report here..."></textarea>
                    <button onclick="submitReport('<?php echo $app_id ?>','<?php echo $phone ?>')"
                            class="c-btn c-btn--info u-m-small" data-dismiss="modal">
                        Send Now
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php
}
?>
<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->

<div class="container">
    <div class="u-mt-small">
        <?php
        foreach ($rep

                 as $key => $value) {
            $re = (object)$value;
            ?>
            <div class="c-project">
                <!--                <div class="c-project__img">-->
                <!--                    <img onerror=this.src="img/avatar6-72.jpg"-->
                <!--                         src="-->
                <?php //echo PRO_APPS . '/' . $re->slider_id . '/' . 'sliders/' . $re->slider_finder ?><!--"-->
                <!--                         alt="Advert">-->
                <!--                </div>-->
                <h4><?php echo $re->name ?></h4>
                <h3 class="c-project__title"><?php echo $re->rep_desc; ?>
                    <span class="c-project__status">Last updated: <span
                                class="u-text-bold"><?php echo time_elapsed_string($re->rep_date); ?></span></span>
                    <span class="c-project__status">Report Status: <span
                                class="u-text-bold"><?php echo ($re->rep_read == 1) ? 'Seen' : 'Pending' ?></span></span>
                </h3>
            </div>
            <?php
        }
        ?>
    </div>

</div>

<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>
    function submitReport(id, user) {

        var reloadWithTurbolinks = (function () {
            var scrollPosition

            function reload() {
                scrollPosition = [window.scrollX, window.scrollY]
                Turbolinks.visit(window.location.toString(), {action: 'replace'})
            }

            document.addEventListener('turbolinks:load', function () {
                if (scrollPosition) {
                    window.scrollTo.apply(window, scrollPosition)
                    scrollPosition = null
                }
            })

            return reload
        })()

        var txtmsg = $('#txtreport').val();
        if (txtmsg.toString().length > 20) {
            //Logic to delete the item
            NProgress.start();
            //start sending info
            $.ajax({
                headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
                type: "POST",
                url: "api",
                data: {rep_id: id, rep_reporter: user, rep_desc: txtmsg, act: 'insert-report'},
                success: function (data) {
                    var obj = JSON.parse(data);
                    if (obj.status) {
                        reloadWithTurbolinks();
                    }
                    NProgress.done();
                }
            });
            return false;

        } else {
            Toast("Report too small or is empty...");
        }


    }
</script>
</body>
</html>