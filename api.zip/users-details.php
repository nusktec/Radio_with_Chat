<?php
require('lib/config.php');
require('assembly.php');
check_login();
page_identity(7, "User Details");
?>
<!doctype html>
<html lang="en-us">
<?php include 'header-js.php' ?>
<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->
<?php include 'addons/header.php' ?>

<div class="container">
    <?php include 'addons/left-bar.php' ?>
    <!--Left side bar-->

    <div id="pages" v-html="htmldata.raw" class="col-md-7 col-xl-6">
        <?php
        $page = (@$_POST['page-no'] == null) ? 500 : (int)@$_POST['page-no'];

        //Read from temporal//
        $app_id = $_SESSION[DP_APP_ID];
        $db = new Db();
        $rd = $db->query("select * from `users` where `app_id`='" . $app_id . "' order by `id` desc");
        $rdCount = $db->query("select * from `reports` where `rep_id`='" . $app_id . "' and `rep_read`=1");
        //fetch slider
        $reports = $db->query("select * from `reports` inner join `users` on `reports`.`rep_reporter`=`users`.`phone` where `reports`.`rep_id`='" . $app_id . "' order by `reports`.`rep_finder` desc");
        if ($reports->num_rows == 0) {
            $reports = array();
        }
        ?>
        <main>
            <div class="c-card u-p-medium u-text-small u-mb-small">
                <h6 class="u-text-bold">View Users</h6>
                <dl class="u-flex u-pv-small u-border-bottom">
                    <dd class="c-badge c-badge--secondary u-mr-small">Total
                        Reports: <?php echo ($rd == null) ? '0' : $rd->num_rows; ?></dd>
                    <dd class="c-badge c-badge--secondary">Viewed
                        Reports: <?php echo ($rdCount == null) ? '0' : $rdCount->num_rows; ?></dd>
                </dl>
            </div>

            <div class="c-card u-mb-medium">
                <h6 class="u-text-bold u-p-medium"></h6>
                <div class="o-page__card">
                    <div class="c-card u-mb-small">
                        <div class="c-card__body">
                            <form target="_blank" action="users-more" method="post">
                                <div class="c-field has-icon-right u-mb-xsmall">
                            <span class="c-field__icon">
                                <i class="fa fa-search"></i>
                            </span>
                                    <label class="c-field__label u-hidden-visually" for="input-search">Search for
                                        user</label>
                                    <input required="required" name="phone" class="c-input" id="input-search"
                                           type="text"
                                           placeholder="Search for users..">
                                </div>
                                <button class="c-btn c-btn--info c-btn--fullwidth">Search</button>
                            </form>
                        </div>

                        <!--List Users-->
                            <div class="c-card u-p-medium c-messages" style="max-height: 400px">

                                <?php
                                foreach ($rd->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                                    $ls = (object)$value;
                                    $rd_read = $db->query("select * from `connects` where `con_id`='" . $app_id . "' and `con_user`='" . $ls->phone . "'");
                                    ?>
                                    <div class="c-fileitem c-message">
                                        <div class="c-fileitem__content u-mr-small">
                                            <a href="users-more?phone=<?php echo $ls->phone; ?>" target="_blank">
                                                <div title="Click to view more" class="c-fileitem__img">
                                                    <img onerror=this.src="img/avatar6-72.jpg"
                                                         src="<?php echo PRO_IMG . '/' . $ls->phone ?>" alt="User Img">
                                                </div>
                                            </a>
                                            <p class="u-text-small u-text-mute">
                                                <?php echo substr($ls->name, 0, 30) . " "; ?>
                                                <br/>
                                                <small class="u-color-behance" ><?php echo substr($ls->phone, 0, 30) . " "; ?></small>
                                            </p>
                                            <small class="u-ml-small u-color-behance u-text-small">
                                                Connects: <?php echo $rd_read->num_rows ?></small>
                                        </div>
                                        <div class="c-fileitem__date">
                                            <p class="u-text-small u-text-mute">
                                                <?php echo time_elapsed_string((int)$ls->lastseen); ?>
                                            </p>
                                        </div>
                                    </div><!-- // .c-fileitem -->
                                    <?php
                                }
                                ?>
                            </div>
                        <!--End of user list-->

                    </div>
                </div>

            </div>
            <!-- DEV NOTE:
                Remove `c-settings` and replace it with flex utilities
             -->

    </div>

    <!--Right Bar-->
    <?php include 'addons/right-bar.php' ?>

</div>
<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>

</script>
</body>
</html>