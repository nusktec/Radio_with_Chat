<?php
require('lib/config.php');
require('assembly.php');
check_login();
page_identity(6, "More Details");
?>
<!doctype html>
<html lang="en-us">
<?php include 'header-js.php' ?>
<body class="o-page o-page--center">
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->

<?php
$phone = @(empty($_POST['phone']))?$_GET['phone']:$_POST['phone'];
$phone = fNumber($phone);
$app_id = $_SESSION[DP_APP_ID];
//pull from data
$db = new Db();
$usr = $db->query("select * from `users` where `phone`='$phone' and `app_id`='$app_id' limit 1");
?>

<div class="o-page__card">
    <div class="c-card u-mb-small">
        <div class="c-card__body">
            <?php
            if ($usr != null && $usr->num_rows > 0) {
                $usr = $usr->fetch_object();
                $rep = $db->query("select * from `connects` where `con_user`='$phone' and `con_id`='$app_id'");
                ?>
                <div class="c-project-card u-mb-medium">
                    <img class="c-project-card__img" src="PROFILE_IMG/<?php echo @$usr->phone ?>" alt="About the image" onerror=this.src="img/project-board7.jpg" >

                    <div class="c-project-card__content">
                        <div class="c-project-card__head">
                            <h4 class="c-project-card__title u-text-bold"><?php echo @$usr->name ?></h4>
                            <p class="c-project-card__info"><?php echo @$usr->phone ?></p>
                        </div>


                        <div class="c-project-card__meta">
                            <p>Location
                                <a target="_blank" href="https://www.google.com/maps/@<?php echo $usr->latlng ?>" class="u-block u-text-mute c-nav__link">View Now</a>
                            </p>
                            <p>Last Online
                                <small class="u-block u-text-danger"><?php echo @time_elapsed_string($usr->lastseen)." ago"; ?></small>
                            </p>
                        </div>
                    </div>
                </div>
                <?php
            }else{
                echo "<p class='u-p-medium align-self-center u-text-center' style='color: red'>No User Records...</p>";
            }
            ?>
            <form action="" method="post">
                <div class="c-field has-icon-right u-mb-xsmall">
                            <span class="c-field__icon">
                                <i class="fa fa-search"></i>
                            </span>
                    <label class="c-field__label u-hidden-visually" for="input-search">Search</label>
                    <input name="phone" required="required" value="<?php echo $phone; ?>" class="c-input" id="input-search" type="text" placeholder="Search for users..">
                </div>
                <button class="c-btn c-btn--info c-btn--fullwidth">Search</button>
            </form>
        </div>
    </div>

    <div class="o-line u-justify-center">
        <a class="u-text-mute" href="javascript:void(0)" onclick="self.close();">
            <i class="fa fa-long-arrow-left u-mr-xsmall"></i>Back to Homepage
        </a>
    </div>

</div>

</body>
<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>

</script>
</body>
</html>