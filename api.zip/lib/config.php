<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/10/2018
 * Time: 10:22 PM
 */
//error_reporting(0);
date_default_timezone_set('africa/lagos');

session_start();
require_once('config.php');
require_once("mysqli.class.php");
require_once("systems.php");

const HRC_TABLE_LICENSE = "users";
const DP_ACCOUNT = "account";
const DP_PASSWORD = "password";
const DP_APP_ID = "app_id";
const DP_ACCOUNT_SETTINGS = "settings";

//folder names
const PRO_IMG = "PROFILE_IMG";
const PRO_APPS = "APPS";
$PRO_SLIDER = PRO_APPS."/".@$_SESSION[DP_APP_ID]."/sliders";
$PRO_ARTICLE = PRO_APPS."/".@$_SESSION[DP_APP_ID]."/articles";
$PRO_PRESENTER = PRO_APPS."/".@$_SESSION[DP_APP_ID]."/presenters";

$APP_TMP = @$_SESSION[DP_ACCOUNT];
$info = array(
    'site-name' => 'Druplay',
    'descriptions' => 'Druplay Connect',
    'tags' => 'radio,music,live,record,fm.dj',
    'site-url' => '',
);

$config['db_host'] = "localhost";
$config['db_username'] = "root";
$config['db_password'] = "";
$config['db_name'] = "druplay_db";

function check_login()
{
    global $APP_TMP;
    if (empty($APP_TMP)) {
        header("location: sign-in");
    }
    $db = new Db();
    $chk = $db->row("select * from `account` where `app_email`='" . $_SESSION[DP_ACCOUNT] . "' and `app_pass`='" . $_SESSION[DP_PASSWORD] . "' limit 1");
    if (!$chk) {
        header("location: log-out");
    }
    if (!file_exists(PRO_APPS."/".$chk->app_id)) {
        @mkdir(PRO_APPS."/".$chk->app_id);
        @mkdir(PRO_APPS."/".$chk->app_id."/sliders");
        @mkdir(PRO_APPS."/".$chk->app_id."/articles");
        @mkdir(PRO_APPS."/".$chk->app_id."/presenters");
    }

    if(!file_exists(PRO_APPS."/".$chk->app_id."/presenters")){
        @mkdir(PRO_APPS."/".$chk->app_id."/presenters");
    }
}

function page_identity($menu, $title)
{
    $_SESSION['menu'] = $menu;
    $_SESSION['title'] = $title;
}

function mountFolder()
{
    if (!file_exists(PRO_IMG)) {
        @mkdir(PRO_IMG);
    }

    if (!file_exists(PRO_APPS)) {
        @mkdir(PRO_APPS);
    }
}

mountFolder();