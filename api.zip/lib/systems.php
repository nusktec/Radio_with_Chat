<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/14/2018
 * Time: 8:35 AM
 */

//Druplay output structure
function druplay_output($status=false,$message="",$meta_data=array("")){
    return json_encode(array("status"=>$status,"message"=>$message,"meta-data"=>$meta_data));
}

//Druplay output structure 2
function druplay_output2($status=false,$message="",$meta_data=array("")){
    return json_encode(array("status"=>$status,"message"=>$message,"data"=>$meta_data));
}


//Druplay output structure 3
function druplay_output3($status=false,$message="",$meta_data=array(""),$meta_data2=array("")){
    return json_encode(array("status"=>$status,"message"=>$message,"data1"=>$meta_data,"data2"=>$meta_data2));
}

//Password validator
function druplay_password($password){
    return sha1(base64_encode($password));
}

//Format phone number
function fNumber($phone){
    if(empty($phone)){
        return "";
    }
    $phone_number = preg_replace('/^0/','234',$phone);
    return str_replace("+","",$phone_number);
}

function time_elapsed_string($ptime)
{
    if(empty($ptime)){
        return "No Time";
    }
    $etime = time() - $ptime;

    if ($etime < 1) {
        return '0 seconds';
    }

    $a = array(365 * 24 * 60 * 60 => 'year',
        30 * 24 * 60 * 60 => 'month',
        24 * 60 * 60 => 'day',
        60 * 60 => 'hour',
        60 => 'min',
        1 => 'sec'
    );
    $a_plural = array('year' => 'years',
        'month' => 'months',
        'day' => 'days',
        'hour' => 'hours',
        'min' => 'min',
        'sec' => 'secs'
    );

    foreach ($a as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);
            return $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . '';
        }
    }
}