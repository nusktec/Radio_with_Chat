<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/21/2018
 * Time: 9:58 PM
 */
?>
<a class="c-table__title-action u-text-small c-nav__link" href="javascript:void(0)" data-toggle="modal"
   data-target="#uploader_frame">
    <i class="fa fa-cloud-upload"></i> Add New
</a>
<!-- Modal -->
<div class="c-modal c-modal--xsmall modal fade" id="uploader_frame" tabindex="-1" role="dialog" aria-labelledby="modal7"
     data-backdrop="static" style="display: none;" aria-hidden="true">
    <div class="c-modal__dialog modal-dialog" role="document">
        <div class="c-modal__content">

            <div class="c-modal__header">
                <h3 class="c-modal__title">Druplay File Uploader</h3>

                <span class="c-modal__close" data-dismiss="modal" aria-label="Close">
                                        <i class="fa fa-close"></i>
                                    </span>
            </div>

            <div class="c-modal__body">
                <div class="c-field u-mb-xsmall" data-select2-id="24">
                    <label class="c-field__label" for="select12">Add new slider</label>
                </div>

                <form enctype="multipart/form-data" id="uploaderForm" method="post" action="xapi"
                      onsubmit="return uploader()">
                    <div class="c-field u-mb-xsmall">
                        <label class="c-field__label" for="link">Url / Web address</label>
                        <input id="title" name="link" class="c-input" type="text" placeholder="www.druplay.com">
                    </div>
                    <div class="c-field u-mb-xsmall">
                        <label class="c-field__label" for="link">Title (Company Name)</label>
                        <input required="required" id="title" name="title" class="c-input" type="text" placeholder="Druplay Technology">
                    </div>
                    <div class="c-field u-mb-xsmall">
                        <label class="c-field__label" for="desc">Description / Content</label>
                        <textarea maxlength="150" required="required" class="c-input" id="desc" name="desc"></textarea>
                    </div>

                    <div class="c-project-card u-mb-medium">
                        <img id="preview" class="c-project-card__img" src="img/project-card1.jpg" alt="About the image">
                        <div class="c-project-card__content">
                            <div class="c-project-card__head">
                                <div class="c-field u-mb-xsmall">
                                    <label class="c-field__label" for="image">Choose post content image</label>
                                    <input required="required" onchange="readImage(this)"
                                           accept="image/gif, image/jpeg, image/png" type="file" class="c-input"
                                           id="image" name="slider"/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="act" value="insert-slider"/>
                    <input type="hidden" name="uploader" value="true"/>
                    <button type="submit" class="c-btn c-btn--success c-btn--fullwidth">
                        Submit
                    </button>
                </form>

            </div>

        </div>
    </div>
</div>
<script>
    function uploader() {
        NProgress.start();
        //start sending info
//        $.ajax({
//            headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
//            type: "POST",
//            url: "xapi",
//            data: $('#uploaderForm').serialize(),
//            success: function (data) {
//                var obj = JSON.parse(data);
//                if (obj.status) {
//                    Turbolinks.visit('dash');
//                }
//                Toast("Slider not added");
//                NProgress.done();
//            }
//        });
    }

    //load image
    function readImage(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#preview')
                    .attr('src', e.target.result)
                    .height(200);
            };
            reader.readAsDataURL(input.files[0]);
//
//            var file = input.files[0];
//            var reader2 = new FileReader();
//            reader2.onloadend = function() {
//                $('#keepimg').val(reader2.result);
//            }
//            reader2.readAsDataURL(file);
        }
    }

    //convert it
</script>
