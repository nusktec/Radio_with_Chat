<?php
require('lib/config.php');
require('assembly.php');
check_login();
page_identity(3, "Connects");
?>
<!doctype html>
<html lang="en-us">
<?php include 'header-js.php' ?>
<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->
<?php include 'addons/header.php' ?>

<div class="container">
    <?php include 'addons/left-bar.php' ?>
    <!--Left side bar-->

    <div id="pages" v-html="htmldata.raw" class="col-md-7 col-xl-6">
        <?php
        $page = (@$_POST['page-no']==null)?200:(int)@$_POST['page-no'];

        //Read from temporal//
        $app_id = $_SESSION[DP_APP_ID];
        $db = new Db();
        $rd = $db->query("select * from `articles` where `art_id`='" . $app_id . "'");
        $rd_read = $db->query("select * from `connects` where `con_id`='" . $app_id . "'");
        //fetch slider
        $articles = $db->query("select * from `articles` where `art_id`='" . $app_id . "' order by `art_finder` desc limit $page");
        if ($articles->num_rows == 0) {
            $articles = array();
        }
        ?>
        <main>
            <div class="c-card u-p-medium u-text-small u-mb-small">
                <h6 class="u-text-bold">Manage Articles</h6>
                <dl class="u-flex u-pv-small u-border-bottom">
                    <dd><?php $count = ($rd==null)?'0':$rd->num_rows; if($count<250){include 'articles_add_class.php';}else{ echo '<p style="color: red">Delete old articles to have more space</p>';} ?></dd>
                </dl>
                <dl class="u-flex u-pv-small u-border-bottom">
                    <dd class="c-badge c-badge--secondary u-mr-small">Total Articles: <?php echo ($rd==null)?'0':$rd->num_rows; ?></dd>
                    <dd class="c-badge c-badge--secondary">Total Responses: <?php echo ($rd_read==null)?'0':$rd_read->num_rows; ?></dd>
                </dl>
            </div>
            <div class="c-card u-p-medium u-mb-medium">
                <h6 class="u-text-bold">Live Articles</h6>
                <div class="c-card u-p-medium c-messages" style="max-height: 400px">
                    <?php
                    foreach ($articles as $key => $value) {
                        $ls = (object)$value;
                        $rd_read = $db->query("select * from `connects` where `con_id`='" . $app_id . "' and `con_finder`='".$ls->art_finder."'");
                        $pres = $db->row("select * from `presenters` where `pres_id`='" . $app_id . "' and `pres_finder`='".$ls->art_pres."'");
                        $reader = $db->query("select * from `readers` where `re_id`='$app_id' and `re_art_id`='" . $ls->art_finder . "'");
                        ?>
                        <div class="c-fileitem c-message">
                            <div class="c-fileitem__content u-mr-small">
                                <a href="join-connect?art=<?php echo strtolower($ls->art_finder.'&id='.$ls->art_id.'&ti='.str_replace('#','',$ls->art_title)) ?>" target="_blank">
                                <div title="<?php echo $ls->art_desc ?>" class="c-fileitem__img">
                                    <img onerror=this.src="img/avatar6-72.jpg" src="<?php echo PRO_APPS.'/'.$ls->art_id.'/articles/'.$ls->art_finder ?>" alt="Articles">
                                </div>
                                </a>
                                <p class="u-text-small u-text-mute">
                                    <?php echo substr($ls->art_title, 0, 30) . " "; ?>
                                    <br><small><?php echo ($pres->pres_name==null)?'':$pres->pres_name." | ".$pres->pres_program ?> </small>
                                </p>
                                <dd class="c-badge u-text-mute"><?php echo 'Conn: '.$rd_read->num_rows.' Reacts: '.$reader->num_rows?></dd>
                            </div>
                            <div class="c-fileitem__date">
                                <p class="u-text-small u-text-mute">
                                    <?php echo time_elapsed_string($ls->art_date); ?>
                                </p>
                            </div>
                            <div class="c-fileitem__date">
                                <a class="" href="javascript:void(0);"
                                   onclick="removeArticles('<?php echo $ls->art_finder ?>','<?php echo $ls->art_id ?>')">
                                    <i class="fa fa-remove u-color-danger c-btn c-btn--secondary"></i>
                                </a>
                            </div>
                        </div><!-- // .c-fileitem -->
                        <?php
                    }
                    ?>
                </div>
                <form action="" method="post">
                    <select class="c-input" name="page-no">
                        <option value="200">200 Articles</option>
                        <option value="300">300 Articles</option>
                    </select>
                    <input class="c-btn c-btn--fullwidth" type="submit" value="Load"/>
                </form>
            </div>
            <!-- DEV NOTE:
                Remove `c-settings` and replace it with flex utilities
             -->

    </div>

    <!--Right Bar-->
    <?php include 'addons/right-bar.php' ?>

</div>
<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>
    function removeArticles(f, v) {
        var result = confirm("Want to remove the selected article ?");
        if (result) {
            //Logic to delete the item

            NProgress.start();
            //start sending info
            $.ajax({
                headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
                type: "POST",
                url: "xapi",
                data: {finder: f, id: v, act: 'remove-article'},
                success: function (data) {
                    var obj = JSON.parse(data);
                    if (obj.status) {
                        Turbolinks.visit('connect');
                    }
                    Toast("Article not removed");
                    NProgress.done();
                }
            });
            return false;

        }
    }
</script>
</body>
</html>