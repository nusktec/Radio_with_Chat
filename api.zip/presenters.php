<?php
require('lib/config.php');
require('assembly.php');
check_login();
page_identity(6, "Presenters");
?>
<!doctype html>
<html lang="en-us">
<?php include 'header-js.php' ?>
<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->
<?php include 'addons/header.php' ?>

<div class="container">
    <?php include 'addons/left-bar.php' ?>
    <!--Left side bar-->

    <div id="pages" v-html="htmldata.raw" class="col-md-7 col-xl-6">
        <?php
        //Read from temporal//
        $app_id = $_SESSION[DP_APP_ID];
        $db = new Db();
        //fetch slider
        $presx = $db->query("select * from `presenters` where `pres_id`='" . $app_id . "' order by `pres_finder` desc limit 50");
        if ($presx->num_rows == 0) {
            $presx = array();
        }
        ?>
        <main>
            <div class="c-card u-p-medium u-mb-medium">
                <h6 class="u-text-bold">Manager Presenters</h6>
                <?php if(@$presx->num_rows<50){include 'presenters_up_class.php';}else{echo "<p style='color: red'>Maximum upload is 50</p>";} ?>
                <div class="c-card u-p-medium c-messages" style="max-height: 400px">
                    <!--List Users-->
                        <?php
                        foreach ($presx as $key => $value) {
                            $ls = (object)$value;
                         ?>
                            <div class="c-fileitem c-message">
                                <div class="c-fileitem__content u-mr-small">
                                        <div class="c-fileitem__img c-avatar">
                                            <img onerror=this.src="img/avatar6-72.jpg"
                                                 src="<?php echo $PRO_PRESENTER . '/' . $ls->pres_finder ?>" alt="User Img">
                                        </div>
                                    <p class="u-text-small u-text-mute">
                                        <?php echo substr($ls->pres_name, 0, 30) . " "; ?>
                                        <br/>
                                        <small class="u-color-dribbble" ><?php echo substr($ls->pres_program, 0, 30) . " "; ?></small>
                                    </p>
                                </div>
                                <div class="c-fileitem__date">
                                    <a class="" href="javascript:void(0);"
                                       onclick="removePress('<?php echo $ls->pres_finder ?>','<?php echo $ls->pres_id ?>')">
                                        <i class="fa fa-remove u-color-danger c-btn c-btn--secondary"></i>
                                    </a>
                                </div>
                            </div><!-- // .c-fileitem -->
                            <?php
                        }
                        ?>
                    </div>
                    <!--End of user list-->
            </div>
            <!-- DEV NOTE:
                Remove `c-settings` and replace it with flex utilities
             -->

    </div>

    <!--Right Bar-->
    <?php include 'addons/right-bar.php' ?>

</div>
<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>
    function removePress(f, v) {
        var result = confirm("Want to remove the selected presenter ?");
        if (result) {
            //Logic to delete the item

            NProgress.start();
            //start sending info
            $.ajax({
                headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
                type: "POST",
                url: "xapi",
                data: {finder: f, id: v, act: 'remove-pres'},
                success: function (data) {
                    var obj = JSON.parse(data);
                    if (obj.status) {
                        Turbolinks.visit('presenters');
                    }
                    Toast("Presenters not removed");
                    NProgress.done();
                }
            });
            return false;

        }
    }
</script>
</body>
</html>