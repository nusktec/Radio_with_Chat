<?php
require('lib/config.php');
page_identity(8, 'Connect');
?>
<!doctype html>
<html lang="en-us">
<?php require('header-js.php') ?>
<head>

</head>
<style>
    * {
        -webkit-user-select: none;
    }
</style>
<?php

$phone = (@$_GET['phone'] == null) ? @$_POST['phone'] : @$_GET['phone'];
$app_id = (@$_GET['app_id'] == null) ? @$_POST['app_id'] : @$_GET['app_id'];
$connect_id = (@$_GET['cid'] == null) ? @$_POST['cid'] : @$_GET['cid'];

$client_id = $_SESSION['client'] = fNumber($phone);

$phone = fNumber($phone);

//if (empty($client_id)) {
//    ?>
<!--    <div class="container  o-page--center u-text-center">-->
<!--        <i class="fa fa-file" style="font-size: 48px"></i>-->
<!--        <p class="u-color-danger">No articles on connect !</p>-->
<!--        <br/>-->
<!--        <a href="posts" class="c-btn c-btn--secondary">Refresh</a>-->
<!--    </div>-->
<!--    --><?php
//    return;
//}


$db = new Db();
$connect = $db->query("select * from `connects` where `con_id`='$app_id' and `con_finder`='$connect_id'");
//if ($connect->num_rows == 0) {
//    ?>
<!--    <div class="container  o-page--center u-text-center">-->
<!--        <i class="fa fa-file" style="font-size: 48px"></i>-->
<!--        <p class="u-color-danger">No connect !</p>-->
<!--        <br/>-->
<!--        <a href="posts" class="c-btn c-btn--secondary">Refresh</a>-->
<!--    </div>-->
<!--    --><?php
//    //return;
//}


?>

<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->

    <div id="msgbox" class="container" style="height: 90%; overflow-x: hidden; max-height: 90%;">
        <div>
            <div id="msgbox">
                <?php
                foreach ($connect->fetch_all(MYSQLI_ASSOC) as $key => $value) {
                    $ls = (object)$value;
                    ?>
                    <div class="c-message"
                       href="javascript:void(0)">
                        <div class="o-media">
                            <div class="o-media__img u-mr-small">
                                <div class="c-avatar c-avatar--small">
                                    <img class="c-avatar__img" onerror=this.src="img/avatar6-72.jpg"
                                         src="<?php echo 'PROFILE_IMG/' . $ls->con_user ?>"
                                         alt="Images">
                                </div>
                            </div>
                            <div class="o-media__body">
                                <span class="c-message__time"><?php echo time_elapsed_string($ls->con_date) . " ago" ?></span>
                            </div>
                        </div>
                        <!--
                        <span class="c-message__counter u-hidden-down@desktop">1</span>
                         -->
                        <p class="c-message__snippet"><?php echo $ls->con_desc ?></p>
                    </div><!-- // .c-message -->
                    <?php
                }
                ?>

            </div>
        </div><!-- // .col-sm-4 -->
    </div>

<div style="width: 90%; text-align: center; bottom: 0px; margin: 5px">

    <a onclick="Turbolinks.visit('posts?app_id=<?php echo $app_id . '&phone=' . $phone; ?>')"
       href="javascript:void(0)" class="u-p-small c-btn c-btn--secondary"><i class="fa fa-arrow-left fa-x2"></i> Back to connects</a>
    <!-- Button trigger modal -->
    <a type="button" class="u-p-small c-btn c-btn--secondary" data-toggle="modal" data-target="#commbox">
        Write A Comment <i class="fa fa-arrow-right fa-x2"></i>
    </a>

    <!-- Modal -->
    <div class="c-modal modal fade" id="commbox" tabindex="-1" role="dialog" aria-labelledby="commbox"
         aria-hidden="true" style="display: none;">
        <div class="c-modal__dialog modal-dialog" role="document">
            <div class="modal-content">
                <div class="c-card u-p-medium u-mh-auto" style="max-width:500px;">
                    <h3>Write a comment...</h3>
                    <textarea class="c-input" id="txtmsg" placeholder="Write a comments"></textarea>
                    <button onclick="addComments('<?php echo $app_id; ?>','<?php echo $connect_id; ?>','<?php echo $phone; ?>')"
                            class="c-btn c-btn--info u-p-small c-btn-fullwidth" data-dismiss="modal" style="width: 100%; margin-top: 5px;">
                        <i class="fa fa-send"></i> Send
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>

<script>
    var reloadWithTurbolinks = (function () {
        var scrollPosition

        function reload() {
            scrollPosition = [window.scrollX, window.scrollY]
            Turbolinks.visit(window.location.toString(), {action: 'replace'})
        }

        document.addEventListener('turbolinks:load', function () {
            if (scrollPosition) {
                window.scrollTo.apply(window, scrollPosition)
                scrollPosition = null
            }
        })

        return reload
    })()

    function addComments(id, cid, user) {
//        var result = confirm("Want to remove the selected article ?");
        var txt = $('#txtmsg').val();
        if (txt !== "") {
            //Logic to delete the item

            NProgress.start();
            //start sending info
            $.ajax({
                headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
                type: "POST",
                url: "api",
                data: {con_finder: cid, con_id: id, con_user: user, con_desc: txt, act: 'add-connects'},
                success: function (data) {
                    var obj = JSON.parse(data);
                    if (obj.status) {
                        Toast(obj.message);
                        reloadWithTurbolinks()
                        $("#msgbox").scrollTop($("#msgbox")[0].scrollHeight);
                        return;
                    }
                    Toast("Unable to add comments");
                    NProgress.done();
                }
            });
            return false;

        } else {
            Toast('Type a comment');
        }
    }

    $(document).ready(function () {
        $("#msgbox").scrollTop($("#msgbox")[0].scrollHeight);
    });
</script>
</body>
</html>