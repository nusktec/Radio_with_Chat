var phpdata = {raw: ''};
var app = new Vue({
    el: '#pages',
    data: {
        htmldata: phpdata
    }
});

//Page waiting info
function pageWaiting() {
    var loader = "<main>\n" +
        "        <img class=\"u-mb-small center\" src='img/loading_2.gif'/></main>";
    return loader;
}

function updatePass() {
    alert('helloo');
    return false;
}