<?php
require('lib/config.php');
require('assembly.php');
check_login();
page_identity(5, "Announcement");
?>
<!doctype html>
<html lang="en-us">
<?php include 'header-js.php' ?>
<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->
<?php include 'addons/header.php' ?>

<div class="container">
    <?php include 'addons/left-bar.php' ?>
    <!--Left side bar-->

    <div id="pages" v-html="htmldata.raw" class="col-md-7 col-xl-6">
        <main>
            <div class="c-card u-p-medium u-text-small u-mb-small">
                <h6 class="u-text-bold">Manage Announcement</h6>
                <dl class="u-flex u-pv-small u-border-bottom">
                    <dd><?php include 'public_anno_frame.php'; ?></dd>
                </dl>
            </div>

            <div class="c-card u-p-medium u-mb-medium">
                <h6 class="u-text-bold">Sent Notifications</h6>
                <div class="c-card u-p-medium">

                </div>
            </div>
            <!-- DEV NOTE:
                Remove `c-settings` and replace it with flex utilities
             -->

    </div>

    <!--Right Bar-->
    <?php include 'addons/right-bar.php' ?>

</div>
<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>
    function removeArticles(f, v) {
        var result = confirm("Want to remove the selected article ?");
        if (result) {
            //Logic to delete the item

            NProgress.start();
            //start sending info
            $.ajax({
                headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
                type: "POST",
                url: "xapi",
                data: {finder: f, id: v, act: 'remove-article'},
                success: function (data) {
                    var obj = JSON.parse(data);
                    if (obj.status) {
                        Turbolinks.visit('connect');
                    }
                    Toast("Article not removed");
                    NProgress.done();
                }
            });
            return false;

        }
    }
</script>
</body>
</html>