<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/13/2018
 * Time: 10:51 AM
 */
error_reporting(0);
$headers = getallheaders()['nsckey'];
if ($headers != "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj==") {
    echo json_encode(array("status" => false, "message" => "invalid token"));
    exit(0);
}

require('lib/config.php');

//mount folder
mountFolder();

$action = $_POST['act'];
switch ($action) {
    case 'sign-up':
        signUp();
        break;
    case 'adduser':
        addUser();
        break;
    case 'update-data':
        updateUserData();
        break;
    case 'readuser':
        readUser();
        break;
    case 'read-radio':
        loadRadioData();
        break;
    case 'add-likes':
        addLikes();
        break;
    case 'add-connects':
        addConnect();
        break;
    case 'insert-report':
        addReport();
        break;
    default:
        exit(0);
}

//submit reports
function addReport()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, $item . " is empty", array());
            break;
        }
    }
    $d = new DateTime();
    $db = new Db();
    unset($_POST['act']);
    $_POST['rep_date'] = $d->getTimestamp();
    $ins = $db->insert("reports", $_POST);
    if ($ins['status'] == 1) {
        echo druplay_output(true, "Reported !", array());
        return;
    }
    echo druplay_output(false, "Unable to add reprots", array());
}

//Adding connects
function addConnect()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, $item . " is empty", array());
            break;
        }
    }
    $d = new DateTime();
    $db = new Db();
    unset($_POST['act']);
    $_POST['con_date'] = $d->getTimestamp();
    $ins = $db->insert("connects", $_POST);
    if ($ins['status'] == 1) {
        echo druplay_output(true, "Comment added !", array());
        return;
    }
    echo druplay_output(false, "Unable to add comments", array());
}

//adding likes and unlinking
function addLikes()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, $item . " is empty", array());
            break;
        }
    }
    $id = $_POST['id'];
    $finder = $_POST['finder'];
    $user = $_POST['user'];
    $db = new Db();
    $chk = $db->row("select * from `readers` where `re_id`='$id' and `re_art_id`='$finder' and `re_user`='$user'");
    switch ($_POST['role']) {
        case 'l':

            if ((int)$chk->re_type == 1) {
                $db->delete("readers", array("re_art_id" => $finder, "re_id" => $id, "re_user" => $user, "re_type" => 1));
                echo druplay_output(true, "Unliked", array());
                return;
            }
            if ($chk == null) {
                $db->insert("readers", array("re_user" => $user, "re_art_id" => $finder, "re_id" => $id, "re_type" => 1));
                echo druplay_output(true, "+1 Liked", array());
                return;
            }
            if ($chk != null && $chk->re_type == "2") {
                $db->update("readers", array("re_user" => $user, "re_art_id" => $finder, "re_id" => $id, "re_type" => 1), array("re_user" => $user, "re_art_id" => $finder, "re_id" => $id, "re_type" => 2));
                echo druplay_output(true, "+1 Liked", array());
                return;
            }
            break;
        case 'd':
            if ($chk != null && (int)$chk->re_type == 2) {
                $db->delete("readers", array("re_art_id" => $finder, "re_id" => $id, "re_user" => $user, "re_type" => 2));
                echo druplay_output(true, "Unbroken Heart", array());
                return;
            }
            if ($chk == null) {
                $db->insert("readers", array("re_user" => $user, "re_art_id" => $finder, "re_id" => $id, "re_type" => 2));
                echo druplay_output(true, "+1 Heart Broken", array());
                return;
            }
            if ($chk != null && (int)$chk->re_type == 1) {
                $db->update("readers", array("re_user" => $user, "re_art_id" => $finder, "re_id" => $id, "re_type" => 2), array("re_user" => $user, "re_art_id" => $finder, "re_id" => $id, "re_type" => 1));
                echo druplay_output(true, "+1 Broken Heart", array());
                return;
            }
            break;
        default:
            exit(0);
    }
}

//Read radio and load streaming key + sliders
function loadRadioData()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, $item . " is empty", array());
            break;
        }
    }
    //approach db
    $app_id = $_POST['app_id'];
    $db = new Db();
    $radio_data = $db->row("select * from `account` inner join `settings` on `settings`.`set_id`=`account`.`app_id` where `account`.`app_id`='$app_id'");
    if ($radio_data) {
        //read sliders
        $slider = $db->query("select * from `sliders` where `slider_id`='$app_id' order by `slider_finder` desc limit 10");
        $slider = $slider->fetch_all(MYSQLI_ASSOC);
        echo druplay_output3(true, "OK", $radio_data, $slider);
        return;
    } else {
        echo druplay_output(false, "Radio server not found or deactivated...");
    }
    var_dump($db);
}

function readUser()
{
    $db = new Db();
    if (!empty($_POST['phone'])) {
        $phone = fNumber($_POST['phone']);
        $rd = $db->row("select * from `users` where `phone`='$phone' limit 1");
        $rd = (array)$rd;
        echo druplay_output(true, "OK", $rd);
        return;
    }
    echo druplay_output(false, "Something went wrong !", array());
}

function signUp()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, $item . " is empty", array());
            break;
        }
    }
    //start validating lkey
    if ($_POST['pass1'] != $_POST['pass2']) {
        echo druplay_output(null, "Password not the same");
    }
}

//Update user reports
function updateUserData()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, $item . " is empty", array());
            break;
        }
    }
    $db = new Db();
    //prepare for user updates
    switch ($_POST['grp']) {
        case 'lastseen':
            $str_time = new DateTime();
            $upd = $db->update("users", array($_POST['grp'] => $str_time->getTimestamp()), array("phone" => fNumber($_POST['phone'])));
            var_dump($upd);
            if ($upd == true) {
                echo druplay_output(true, "OK", array());
                return;
            }
            echo druplay_output(false, "Failed", array());
            break;
        default:
            $upd = $db->update("users", array($_POST['grp'] => $_POST['data']), array("phone" => $_POST['phone']));
            if ($upd == true) {
                echo druplay_output(true, "OK", array());
                return;
            }
            echo druplay_output(false, "Failed", array());
            exit(0);
    }
}

function addUser()
{
    $db = new Db();
    $ready = true;
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, $item . " is empty", array());
            $ready = false;
            break;
        }
    }
    if (!$ready) {
        echo druplay_output(false, "Unknown issues", array());
        return;
    }
    //Get time stamp
    $d = new DateTime();
    $phone = fNumber($_POST['phone']);
    $data = array("name" => ucwords($_POST['name']), "phone" => $phone, "latlng" => $_POST['latlng'], "date_time" => date('d-m-Y h:i:s p'), "lastseen" => $d->getTimestamp(), "app_id" => $_POST['app_id']);
    $ins = $db->insert("users", $data);
    if ($ins['status'] == '1') {
        //write image to file
        file_put_contents(PRO_IMG . "/" . $phone, base64_decode($_POST['pimg']));
        echo druplay_output(true, "You have joined the rights connect family", array("phone" => $phone));
    } elseif ($ins['status'] == '2') {
        $db->update("users", $data, array("phone" => $phone));
        file_put_contents(PRO_IMG . "/" . $phone, base64_decode($_POST['pimg']));
        echo druplay_output(true, "Already a member, proceed to join your family", array("phone" => $phone));
    }
}
