<?php
require('lib/config.php');
require('assembly.php');
check_login();
page_identity(3, "Chat - Connects");
?>
<!doctype html>
<html lang="en-us">
<?php include 'header-js.php' ?>
<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->
<?php include 'addons/header.php' ?>

<div class="container">

    <?php
    $page = (@$_POST['page-no'] == null) ? 250 : (int)@$_POST['page-no'];

    //Read from temporal//
    $app_id = $_SESSION[DP_APP_ID];
    $db = new Db();
    $rd = $db->query("select * from `articles` where `art_id`='" . $app_id . "'");
    $rd_read = $db->query("select * from `connects` where `con_id`='" . $app_id . "'");
    //fetch slider
    $articles = $db->query("select * from `articles` where `art_id`='" . $app_id . "' order by `art_finder` desc limit $page");
    if ($articles->num_rows == 0) {
        $articles = array();
    }
    ?>

    <div id="app" class="o-page container-fluid">

        <div class="container-fluid c-messanger">
            <div class="row">
                <!--
                <div class="col-sm-4 u-p-zero">
                    <div class="u-p-small u-border-bottom u-border-right">
                        <div class="c-field has-icon-right">
                            <input class="c-input" type="text" placeholder="Search">
                            <span class="c-field__icon">
                                <i class="fa fa-search"></i>
                            </span>
                        </div>
                    </div>
                </div>
                -->
                <div class="col-sm-8 u-p-zero">
                    <div class="u-height-100 u-flex u-align-items-center u-border-bottom u-p-medium">
                        <h2 v-html="htmldata.art" class="c-badge c-badge--success u-mb-zero u-ml-medium">Article
                            Name</h2>
                        <span class="u-ml-xsmall u-text-tiny u-mr-auto">
                                <i class="fa fa-circle u-color-success"></i>
                            </span>
                    </div>
                </div>
            </div><!-- // .row -->

            <div class="row">
                <div class="col-sm-4 u-p-zero">
                    <div class="c-messages">
                        <?php
                        foreach ($articles as $key => $value) {
                            $ls = (object)$value;
                            $rd_read = $db->query("select * from `connects` where `con_id`='" . $app_id . "' and `con_finder`='" . $ls->art_finder . "'");
                            $reader = $db->query("select * from `readers` where `re_id`='$app_id' and `re_art_id`='" . $ls->art_finder . "'");
                            ?>
                            <a class="c-message"
                               onclick="loadMessage('<?php echo $ls->art_finder ?>','<?php echo $app_id ?>','<?php echo $ls->art_title ?>')"
                               href="javascript:void(0)">
                                <div class="o-media">
                                    <div class="o-media__img u-mr-small">
                                        <div class="c-avatar c-avatar--small">
                                            <img class="c-avatar__img" onerror=this.src="img/avatar6-72.jpg"
                                                 src="<?php echo PRO_APPS . '/' . $ls->art_id . '/articles/' . $ls->art_finder ?>"
                                                 alt="Images">
                                        </div>
                                    </div>
                                    <div class="o-media__body">
                                        <h4 class="c-message__title"><?php echo $ls->art_title ?>
                                            <span class="c-message__title-meta">Connects: <?php echo $rd_read->num_rows; ?> Reacts: <?php echo $reader->num_rows; ?></span>
                                        </h4>
                                        <span class="c-message__time"><?php echo time_elapsed_string($ls->art_date) . " ago" ?></span>
                                    </div>
                                </div>
                                <!--
                                <span class="c-message__counter u-hidden-down@desktop">1</span>
                                 -->
                                <p class="c-message__snippet"><?php echo $ls->art_desc ?></p>
                            </a><!-- // .c-message -->
                            <?php
                        }
                        ?>

                    </div>
                </div><!-- // .col-sm-4 -->

                <div class="col-sm-8 u-p-zero">
                    <div class="c-chat">
                        <div class="c-chat__body">

                            <div v-if="htmldata.sload" v-html="htmldata.pb" id="loader">

                            </div>

                            <div v-for="item in htmldata.raw" v-if="htmldata.hasload" class="c-chat__message o-media">
                                <div id="msg" class="c-message">
                                    <a target="_blank" :href="'users-more?phone='+item.phone">
                                    <div class="o-media__img u-mr-small">
                                        <div class="c-avatar c-avatar--small">
                                            <div class="c-avatar__img">
                                                <img onerror=this.src="img/avatar6-72.jpg" :src="item.image"/>
                                            </div>
                                        </div>
                                    </div><!-- // .o-media__img -->
                                    </a>
                                    <div class="o-media__body">
                                        <h4 class="c-chat__message-author">{{item.name}}</h4>
                                        <span id="showtime" class="c-chat__message-time timeago">{{item.time}}</span>
                                        <p class="c-chat__message-content">{{item.con_desc}}</p>
                                    </div>
                                </div>

                            </div>

                        </div><!-- // .c-chat__body -->

                        <!--
                        <form class="c-chat__composer">
                            <div class="c-field has-addon-right">
                                <input class="c-input" type="text" placeholder="Clark">
                                <button type="submit" class="c-field__addon"><i class="fa fa-send u-color-success"></i></button>
                            </div>
                        </form><!-- // .c-chat__composer -->
                    </div>
                </div><!-- // .col-sm-8 -->
            </div><!-- // .row -->
        </div><!-- // .container -->

    </div>

</div>
<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>
    //vue js
    var phpdata = {raw: '', hasload: false, sload: true, pb: '', art: ''};
    var app = new Vue({
        el: '#app',
        data: {
            htmldata: phpdata
        }
    });

    //loading
    phpdata.pb = pageWaiting();
    phpdata.hasload = false;
    phpdata.sload = true;

    function loadMessage(f, v, ar) {
        var result = true;
        phpdata.pb = pageWaiting();
        phpdata.hasload = false;
        phpdata.sload = true;
        phpdata.art = ar;
        if (result) {
            //Logic to delete the item
            NProgress.start();
            //start sending info
            $.ajax({
                headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
                type: "POST",
                url: "xapi",
                data: {finder: f, id: v, act: 'load-article'},
                success: function (data) {
                    var obj = JSON.parse(data);
                    if (obj.status) {
                        //Loaded...
                        phpdata.pb = pageWaiting();
                        phpdata.hasload = true;
                        phpdata.sload = false;
                        phpdata.raw = obj.data;
                        NProgress.done();
                        $('#showtime').click();
                        return;
                    }
                    Toast('No users articles connect');
                    NProgress.done();
                    phpdata.pb = "<h4 class='u-p-large align-self-center' style='color: red'>No user article connects</h4>";
                }
            });
            return false;

        }
    }

    //kept variable
    var finder = '<?php echo @$_GET['art']; ?>';
    var id = '<?php echo @$_GET['id']; ?>';
    var title = '<?php echo @$_GET['ti']; ?>';
    $(document).ready(function () {
        if (title === null) {
            title = "No Title";
        }
        title = "#" + title;
        loadMessage(finder, id, title);
    });


    //Page waiting info
    function pageWaiting() {
        var loader = "<main>\n" +
            "        <img class=\"u-mb-small center\" src='img/loading_2.gif'/></main>";
        return loader;
    }


    function time2TimeAgo(ts) {
        // This function computes the delta between the
        // provided timestamp and the current time, then test
        // the delta for predefined ranges.
        ts = ts.innerHTML;
        var d=new Date();  // Gets the current time
        var nowTs = Math.floor(d.getTime()/1000); // getTime() returns milliseconds, and we need seconds, hence the Math.floor and division by 1000
        var seconds = nowTs-ts;

        // more that two days
        if (seconds > 2*24*3600) {
            return "a few days ago";
        }
        // a day
        if (seconds > 24*3600) {
            return "yesterday";
        }

        if (seconds > 3600) {
            ts.innerHTML = "few hours ago";
            return "few hours ago";
        }
        if (seconds > 1800) {
            return "an hour ago";
        }
        if (seconds > 60) {
            return Math.floor(seconds/60) + " minutes ago";
        }
    }
</script>
</body>
</html>