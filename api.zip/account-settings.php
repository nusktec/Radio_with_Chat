<?php
require('lib/config.php');
require('assembly.php');
check_login();
page_identity(2,"Settings");
?>
<!doctype html>
<html lang="en-us">
<?php include 'header-js.php' ?>
<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->
<!--Header-->
<?php include 'addons/header.php' ?>
<div class="container">
    <?php include 'addons/left-bar.php' ?>
    <!--Left side bar-->

    <div id="pages" v-html="htmldata.raw" class="col-md-7 col-xl-6">
        <?php
        //Read from temporal//
        $email = $_SESSION[DP_ACCOUNT];
        $pass = $_SESSION[DP_ACCOUNT];
        $db = new Db();
        $rd = $db->row("select * from `account` inner join `settings` on `account`.`app_id`=`settings`.`set_id` where `account`.`app_email`='" . $email . "' LIMIT 1");
        ?>
        <main id="app">
            <div class="c-card u-p-medium u-mb-small">
                <h6 class="u-text-bold">User Control</h6>
                    <p class="u-text-mute u-mb-small">Allow user to comment</p>
                    <form onsubmit="return false" action="" method="post">
                    <div class="c-toggle u-mb-small">
                        <div onclick="updateSettings('auc',1)" class="c-toggle__btn <?php echo ($rd->set_auc==1)?'is-active':''; ?>">
                            <label class="c-toggle__label" for="toggle1">
                                <input  class="c-toggle__input" id="toggle1" name="toggles" type="radio" value="1" checked="">Yes
                            </label>
                        </div>

                        <div onclick="updateSettings('auc',2)" class="c-toggle__btn <?php echo ($rd->set_auc==2)?'c-btn--danger u-color-white':''; ?>">
                            <label class="c-toggle__label" for="toggle2">
                                <input class="c-toggle__input" id="toggle2" name="toggles" value="0" type="radio">No
                            </label>
                        </div>
                    </div><!-- // .c-toggle -->
                    </form>

                <p class="u-text-mute u-mb-small">Allow user to write report</p>
                <form action="" method="post">
                    <div class="c-toggle u-mb-small">
                        <div onclick="updateSettings('aup',1)" class="c-toggle__btn <?php echo ($rd->set_aup==1)?'is-active':''; ?>">
                            <label class="c-toggle__label" for="toggle1">
                                <input class="c-toggle__input" id="toggle1" name="toggles" type="radio" value="1" checked="">Yes
                            </label>
                        </div>

                        <div onclick="updateSettings('aup',2)" class="c-toggle__btn <?php echo ($rd->set_aup==2)?' c-btn--danger u-color-white':''; ?>">
                            <label class="c-toggle__label" for="toggle2">
                                <input class="c-toggle__input" id="toggle2" name="toggles" value="0" type="radio">No
                            </label>
                        </div>
                    </div><!-- // .c-toggle -->
                    <input type="hidden" name="act" value="change-pass">
                </form>
                <!--Update radio link-->
                    <div class="c-field u-mb-small">
                        <label class="c-field__label" for="audiolink">Radio Live Url</label>
                        <input class="c-input" type="text" id="audiolink" value="" placeholder="<?php echo $rd->set_asl ?>">
                    </div>
                    <button onclick="updateSettings('asl',$('#audiolink').val())" class="c-btn c-btn--secondary c-btn--fullwidth" type="submit">Update</button>
                <!--Update radio link-->
                <div class="c-field u-mb-small">
                    <label class="c-field__label" for="audiolink">Radio Alt Url</label>
                    <input class="c-input" type="text" id="audiolink2" value="" placeholder="<?php echo $rd->set_aasl ?>">
                </div>
                <button onclick="updateSettings('aasl',$('#audiolink2').val())" class="c-btn c-btn--secondary c-btn--fullwidth" type="submit">Update</button>

            </div>

            <div class="c-card u-p-medium u-mb-small">
                <h6 class="u-text-bold">Change Password</h6>
                <form id="formPass" action="" method="post" class="c-card__body" onsubmit="return updatePass()">
                    <div class="c-field u-mb-small">
                        <label class="c-field__label" for="old_pass">Your Old Password</label>
                        <input class="c-input" type="password" id="old_pass" name="po" placeholder="Old Password">
                    </div>

                    <div class="c-field u-mb-small">
                        <label class="c-field__label" for="new_pass">Your New Password</label>
                        <input class="c-input" type="password" id="new_pass" name="pn" placeholder="Password">
                    </div>

                    <div class="c-field u-mb-small">
                        <label class="c-field__label" for="new_pass_2">Confirm Password</label>
                        <input class="c-input" type="password" id="new_pass_2" name="pc" placeholder="Re-enter Password">
                    </div>
                    <input type="hidden" name="act" value="change-pass"/>
                    <p class="u-text-mute u-text-center u-mb-small" v-html="message.err"></p>
                    <button class="c-btn c-btn--danger c-btn--fullwidth" type="submit">Change password</button>
                </form>
            </div>
        </main>
    </div>

    <!--Right Bar-->
    <?php include 'addons/right-bar.php' ?>

</div>
<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>
    var msg = {err: ''};
    var app = new Vue({
        el: '#app',
        data: {
            message: msg
        }
    });

    //load the first page
function updatePass() {
    NProgress.start();
    //start sending info
    msg.err = "Confirming, Please wait...";
    $.ajax({
        headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
        type: "POST",
        url: "xapi",
        data: $('#formPass').serialize(),
        success: function (data) {
            var obj = JSON.parse(data);
            if (obj.status) {
                $('#formPass')[0].reset();
            setTimeout(function () {
                Turbolinks.visit("home");
            },4000);
            }
            msg.err = obj.message;
            NProgress.done();
        }
    });
    return false;
}

    function updateSettings(r,v) {
        NProgress.start();
        //start sending info
        $.ajax({
            headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
            type: "POST",
            url: "xapi",
            data: {role: r, value: v, act: 'apply-settings'},
            success: function (data) {
                var obj = JSON.parse(data);
                if (obj.status) {
                    Turbolinks.visit('account-settings');
                }
                Toast('Settings not saved');
                NProgress.done();
            }
        });
        return false;
    }

</script>
</body>
</html>