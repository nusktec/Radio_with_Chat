<?php
require('lib/config.php');
page_identity(8, 'Connect');
?>
<!doctype html>
<html lang="en-us">
<?php require('header-js.php') ?>
<style>
    * {
        -webkit-user-select: none;
    }
</style>
<?php

$phone = (@$_GET['phone'] == null) ? @$_POST['phone'] : @$_GET['phone'];
$app_id = (@$_GET['app_id'] == null) ? @$_POST['app_id'] : @$_GET['app_id'];

$client_id = $_SESSION['client'] = fNumber($phone);

$phone = fNumber($phone);

if (empty($client_id)) {
    ?>
    <div class="container  o-page--center u-text-center">
        <i class="fa fa-file" style="font-size: 48px"></i>
        <p class="u-color-danger">No articles on connect !</p>
        <br/>
        <a href="posts" class="c-btn c-btn--secondary">Refresh</a>
    </div>
    <?php
    return;
}


$db = new Db();
$posts = $db->query("select * from `articles` where `art_id`='$app_id'");

if ($posts->num_rows == 0) {
    ?>
    <div class="container  o-page--center u-text-center">
        <i class="fa fa-file" style="font-size: 48px"></i>
        <p class="u-color-danger">No articles on connect !</p>
        <br/>
        <a href="posts" class="c-btn c-btn--secondary">Refresh</a>
    </div>
    <?php
    return;
}


?>

<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->

<div class="container">
    <div class="row">
        <ol class="">

            <?php
            foreach ($posts as $key => $value) {
                $ps = (object)$value;
                $reader = $db->query("select * from `readers` where `re_id`='$app_id' and `re_art_id`='" . $ps->art_finder . "' and `re_type`=1");
                $reader2 = $db->query("select * from `readers` where `re_id`='$app_id' and `re_art_id`='" . $ps->art_finder . "' and `re_type`=1 and `re_user`='$phone'");
                $dreader = $db->query("select * from `readers` where `re_id`='$app_id' and `re_art_id`='" . $ps->art_finder . "' and `re_type`=2");
                $dreader2 = $db->query("select * from `readers` where `re_id`='$app_id' and `re_art_id`='" . $ps->art_finder . "' and `re_type`=2 and `re_user`='$phone'");
                $conn = $db->query("select * from `connects` where `con_id`='$app_id' and `con_finder`='" . $ps->art_finder . "'");
                $pres = $db->row("select * from `presenters` where `pres_id`='$app_id' and `pres_finder`='" . $ps->art_pres . "'");
                ?>
                <li class="c-stream-item o-media">

                    <div class="c-stream-item__content o-media__body u-bm-large">
                        <h3 class="u-text-bold"><?php echo substr($ps->art_title, 0, 15); ?></h3>
                        <div class="c-stream-item__header">
                            <a class="c-stream-item__name" href="#"><?php echo $pres->pres_name ?><span
                                        class="c-stream-item__username">@<?php echo $pres->pres_program ?></span>
                            </a>
                            <span class="c-stream-item__time"><?php echo time_elapsed_string((float)$ps->art_date) ?></span>
                        </div>

                        <div class="">
                            <!--Future we will itereate more images here-->
                            <img style="border-radius: 5px; " onerror="this.src='img/avatar4-120.jpg'" width="100%"
                                 height="200px" alt="Image"
                                 src="APPS/<?php echo $app_id . "/presenters/" . $ps->art_pres ?>">
                        </div>

                        <p class="u-mb-small"><?php echo $ps->art_desc ?></p>

                        <div class="u-flex u-justify-between">
                            <div class="c-stream-item__actionlist">
                                <a data-turborlinks-action="replace"
                                   onclick="addLikes('<?php echo $ps->art_finder ?>','<?php echo $app_id ?>','l','<?php echo fNumber($phone); ?>')"
                                   class="c-stream-item__action" href="javascript:void(0)">
                                    <i class="fa <?php echo ($reader2->num_rows>0)?'fa-heart u-color-success':'fa-heart-o'; ; ?>"></i><?php echo $reader->num_rows; ?>
                                </a>
                                <a data-turborlinks-action="replace"
                                   onclick="addLikes('<?php echo $ps->art_finder ?>','<?php echo $app_id ?>','d','<?php echo fNumber($phone); ?>')"
                                   class="c-stream-item__action" href="javascript:void(0)">
                                    <i class="fa <?php echo ($dreader2->num_rows>0)?'fa-heartbeat u-color-danger':'fa-heartbeat'; ?>"></i><?php echo $dreader->num_rows; ?>
                                </a>
                                <a onclick="Turbolinks.visit('chat-connect?cid=<?php echo $ps->art_finder.'&phone='.$phone.'&app_id='.$app_id ?>')" class="c-stream-item__action" href="javascript:void(0)">
                                    <i class="fa fa-comment-o"></i><?php echo $conn->num_rows; ?>
                                </a>
                                <a onclick="Toast('Invite friends to download our app !')" class="c-stream-item__action"
                                   href="javascript:void(0)">
                                    <i class="fa fa-share"></i> Share
                                </a>
                            </div>
                        </div>
                    </div>
                </li>

                <?php
            }
            ?>

        </ol><!-- // .c-stream -->

    </div>

</div><!-- // .container -->

<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>

<script>
    var reloadWithTurbolinks = (function () {
        var scrollPosition

        function reload() {
            scrollPosition = [window.scrollX, window.scrollY]
            Turbolinks.visit(window.location.toString(), {action: 'replace'})
        }

        document.addEventListener('turbolinks:load', function () {
            if (scrollPosition) {
                window.scrollTo.apply(window, scrollPosition)
                scrollPosition = null
            }
        })

        return reload
    })()

    function addLikes(f, v, r, u) {
//        var result = confirm("Want to remove the selected article ?");
        if (true) {
            //Logic to delete the item

            NProgress.start();
            //start sending info
            $.ajax({
                headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
                type: "POST",
                url: "api",
                data: {finder: f, id: v, role: r, user: u, act: 'add-likes'},
                success: function (data) {
                    var obj = JSON.parse(data);
                    if (obj.status) {
                        Toast(obj.message);
                        reloadWithTurbolinks()
                        return;
                    }
                    Toast("Unable to like article");
                    NProgress.done();
                }
            });
            return false;

        }
    }
</script>
</body>
</html>