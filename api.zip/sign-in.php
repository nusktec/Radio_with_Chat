<?php
require('lib/config.php');
?>
<!doctype html>
<html lang="en-us">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Sign in | <?php echo $info['site-name']; ?></title>
    <meta name="description" content="<?php echo $info['descriptions']; ?>">
    <meta name="keywords" content="<?php echo $info['tags']; ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400i,600" rel="stylesheet">

    <script type="text/javascript" src="js/turbo.js" difer></script>
    <script type="text/javascript" src="js/vue.js"></script>

    <meta name="turbolinks-cache-control" content="no-cache">
    <!-- Favicon -->
    <link rel="apple-touch-icon" href="img/logo.png">
    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">

    <!-- Stylesheet -->
    <!--<link rel="stylesheet" href="css/main.css">-->
    <link rel="stylesheet" href="css/main.druplay.css">

    <!--TopProgress Bar-->
    <script type="text/javascript" src="js/topBar.js"></script>
    <script type="text/javascript" src="js/toast/toast.js"></script>
    <link rel="stylesheet" href="css/topBar.css"/>
</head>
<body class="o-page o-page--center">
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->

<div class="o-page__card o-page__card--horizontal">
    <div class="c-card c-login-horizontal">
        <div id="app" class="c-login__content-wrapper">
            <header class="c-login__header">
                <a class="c-login__icon c-login__icon--rounded c-login__icon--left" href=""
                   style="background-color: transparent;">
                    <img src="img/logo.png" alt="Dashboard's Logo">
                </a>

                <h2 class="c-login__title">Sign In</h2>
            </header>

            <form action="" id="signForm" onsubmit="return submitData();" method="post" class="c-login__content">
                <div class="c-field u-mb-small">
                    <label class="c-field__label" for="input1">Email Address</label>
                    <input name="email" class="c-input" type="email" id="email" placeholder="info@druplay.com">
                </div>

                <div class="c-field u-mb-small">
                    <label class="c-field__label" for="password">Password</label>
                    <input name="password" class="c-input" type="password" id="password" placeholder="password">
                </div>
                <input type="hidden" name="act" value="sign-in"/>
                <button class="c-btn c-btn--info c-btn--fullwidth" type="submit">Sign in</button>

                <a onclick="alert('No signup page is available...')" href="#"
                   class="c-btn c-btn--secondary c-btn--fullwidth gu-hide">Create Account</a>
            </form>
            <p class="u-text-mute u-text-center u-mb-small" v-html="message.err">

            </p>
            <p style="cursor: pointer" onclick="Turbolinks.visit('https://druplay.com')"
               class="c-nav__link u-text-center u-mb-small"> Druplay Technology</p>
        </div>

        <div class="c-login__content-image">
            <img src="img/images/promo.jpg" alt="Druplay">
            <h3>Welcome to Druplay Connect <i class="fa fa-link c-badge c-badge--primary"></i></h3>
            <p class="u-text-large">Audio Virtual</p>
        </div>
    </div>
    <div class="footer-element o-page--center u-mb-small d-inline-flex u-text-center">
        <p class="u-text-mute">All rights reserved &copy;<?php date("Y"); ?>, Abuja Nig.</p>
    </div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>
    var msg = {err: ''};
    var app = new Vue({
        el: '#app',
        data: {
            message: msg
        }
    });

    function submitData() {
        NProgress.start();
//      var email,pass; email = $('#email'); pass = $('#password');
        msg.err = "Please wait...";
        //start sending info
        $.ajax({
            headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
            type: "POST",
            url: "xapi",
            data: $('#signForm').serialize(),
            success: function (data) {
                var obj = JSON.parse(data);
                if (obj.status) {
                    $('#signForm').submit();
                    Turbolinks.visit("dash");
                }
                msg.err = obj.message;
                NProgress.done();
            }
        });
        return false;
    }

    function Toast(s){
        var toast = new iqwerty.toast.Toast(s);
    }
</script>
</body>
</html>