<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/20/2018
 * Time: 9:45 AM
 */
session_start();
session_destroy();
header("location: sign-in");