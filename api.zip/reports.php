<?php
require('lib/config.php');
require('assembly.php');
check_login();
page_identity(4, "Reports");
?>
<!doctype html>
<html lang="en-us">
<?php include 'header-js.php' ?>
<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->
<?php include 'addons/header.php' ?>

<div class="container">
    <?php include 'addons/left-bar.php' ?>
    <!--Left side bar-->

    <div id="pages" v-html="htmldata.raw" class="col-md-7 col-xl-6">
        <?php
        $page = (@$_POST['page-no'] == null) ? 500 : (int)@$_POST['page-no'];

        //Read from temporal//
        $app_id = $_SESSION[DP_APP_ID];
        $db = new Db();
        $rd = $db->query("select * from `reports` where `rep_id`='" . $app_id . "'");
        $rdCount = $db->query("select * from `reports` where `rep_id`='" . $app_id . "' and `rep_read`=1");
        //fetch slider
        $reports = $db->query("select * from `reports` inner join `users` on `reports`.`rep_reporter`=`users`.`phone` where `reports`.`rep_id`='" . $app_id . "' order by `reports`.`rep_finder` desc");
        if ($reports->num_rows == 0) {
            $reports = array();
        }
        ?>
        <main>
            <div class="c-card u-p-medium u-text-small u-mb-small">
                <h6 class="u-text-bold">Manage Reports</h6>
                <dl class="u-flex u-pv-small u-border-bottom">
                    <dd><?php include 'public_anno_frame.php'; ?></dd>
                </dl>
                <dl class="u-flex u-pv-small u-border-bottom">
                    <dd class="c-badge c-badge--secondary u-mr-small">Total
                        Reports: <?php echo ($rd == null) ? '0' : $rd->num_rows; ?></dd>
                    <dd class="c-badge c-badge--secondary">Viewed Reports: <?php echo ($rdCount == null) ? '0' : $rdCount->num_rows; ?></dd>
                </dl>
            </div>

            <div class="c-card u-mb-medium">
                <h6 class="u-text-bold u-p-medium">Reports From Users</h6>
                <div class="c-messages" style="max-height: 500px">
                    <?php
                    foreach ($reports as $key => $value) {
                        $ls = (object)$value;
                        ?>
                        <div class="c-message" href="">
                            <div class="o-media">
                                <div class="o-media__img u-mr-small">
                                    <div class="c-dropdown dropdown">
                                        <div class="c-avatar c-avatar--small c-avatar has-dropdown dropdown-toggle"
                                             id="dropdownMenuButton3" data-toggle="dropdown" role="menu"
                                             aria-haspopup="true" aria-expanded="false">
                                            <img class="c-avatar__img" src="PROFILE_IMG/<?php echo $ls->phone ?>"
                                                 alt="Image" onerror=this.src="img/project-card2.jpg">
                                        </div>

                                        <div class="c-dropdown__menu dropdown-menu"
                                             aria-labelledby="dropdownMenuButton3" x-placement="bottom-start"
                                             style="position: absolute; transform: translate3d(0px, 70px, 0px); top: 0px; left: 0px; will-change: transform;">
                                            <a class="c-dropdown__item dropdown-item"
                                               onclick="markReport('<?php echo $ls->rep_finder ?>','<?php echo $ls->rep_id ?>')"
                                               href="javascript:void(0)">Mark as read</a>
                                            <a class="c-dropdown__item dropdown-item" target="_blank"
                                               href="https://www.google.com/maps/@<?php echo $ls->latlng ?>">View
                                                Location</a>
                                            <a class="c-dropdown__item dropdown-item u-color-danger"
                                               onclick="deleteReport('<?php echo $ls->rep_finder ?>','<?php echo $ls->rep_id ?>')"
                                               href="javascript:void(0)">Delete Report</a>
                                        </div>
                                    </div>

                                </div>
                                <div class="o-media__body">
                                    <h4 class="c-message__title"><?php echo $ls->name ?>
                                        <span class="c-message__title-meta"><?php echo $ls->phone ?></span></h4>
                                    <span class="c-message__time"><?php echo time_elapsed_string($ls->rep_date) . " ago" ?></span>
                                </div>
                            </div>
                            <?php
                            if (!$ls->rep_read) {
                                echo '<span class="c-message__counter u-hidden-down@desktop"><i class="fa fa-eye-slash"></i></span>';
                            }
                            ?>
                            <p class="c-message__snippet"><?php echo $ls->rep_desc ?></p>
                        </div>
                    <?php } ?>

                </div>
                <form action="" method="post">
                    <select class="c-input" name="page-no">
                        <option selected value="1000">1000 reports</option>
                        <option value="2000">2000 reports</option>
                    </select>
                    <input class="c-btn c-btn--fullwidth" type="submit" value="Load More"/>
                </form>
            </div>
            <!-- DEV NOTE:
                Remove `c-settings` and replace it with flex utilities
             -->

    </div>

    <!--Right Bar-->
    <?php include 'addons/right-bar.php' ?>

</div>
<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>
    function markReport(f, v) {
        var result = true;
        if (result) {
            //Logic to delete the item

            NProgress.start();
            //start sending info
            $.ajax({
                headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
                type: "POST",
                url: "xapi",
                data: {finder: f, id: v, act: 'mark-report'},
                success: function (data) {
                    var obj = JSON.parse(data);
                    if (obj.status) {
                        Turbolinks.visit('reports');
                    }
                    Toast("Unable to mark as read");
                    NProgress.done();
                }
            });
            return false;

        }
    }

    function deleteReport(f, v) {
        var result = confirm('Deleting users post cannot be undone, agreed ?');
        if (result) {
            //Logic to delete the item

            NProgress.start();
            //start sending info
            $.ajax({
                headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
                type: "POST",
                url: "xapi",
                data: {finder: f, id: v, act: 'delete-report'},
                success: function (data) {
                    var obj = JSON.parse(data);
                    if (obj.status) {
                        Turbolinks.visit('reports');
                    }
                    Toast("Unable to delete report");
                    NProgress.done();
                }
            });
            return false;

        }
    }
</script>
</body>
</html>