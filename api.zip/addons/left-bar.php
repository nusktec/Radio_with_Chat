<?php
//Read from temporal//
$app_id = $_SESSION[DP_APP_ID];
$db = new Db();
$rd = $db->query("select * from `articles` where `art_id`='" . $app_id . "'");
$rd_app = $db->query("select * from `users` where `app_id`='" . $app_id . "'");
$rd_rep = $db->query("select * from `reports` where `rep_id`='" . $app_id . "'");
?>
<div class="row">
    <div class="col-xl-3 u-hidden-down@wide">
        <aside class="c-menu u-ml-medium">
            <h4 class="c-menu__title">Menu</h4>
            <ul class="u-mb-medium">
                <li class="c-menu__item">
                    <a data-turbolinks-replace="replace"
                       class="c-menu__link <?php echo ($_SESSION['menu'] == 1) ? 'is-active' : ''; ?>" href="dash">
                        <i class="fa fa-user u-mr-xsmall"></i>Account Overview
                    </a>
                </li>
                <li class="c-menu__item">
                    <a data-turbolinks-replace="replace"
                       class="c-menu__link <?php echo ($_SESSION['menu'] == 2) ? 'is-active' : ''; ?>"
                       href="account-settings">
                        <i class="u-mr-xsmall fa fa-gear"></i>Account Settings
                    </a>
                </li>
            </ul>

            <h4 class="c-menu__title">Audience</h4>
            <ul class="u-mb-medium">
                <li class="c-menu__item">
                    <a data-turbolinks-replace="replace"
                       class="c-menu__link <?php echo ($_SESSION['menu'] == 3) ? 'is-active' : ''; ?>" href="connect">
                        <i class="fa fa-users u-mr-xsmall"></i>Articles / Connect
                    </a>
                </li>
                <li class="c-menu__item">
                    <a data-turbolinks-replace="replace"
                       class="c-menu__link <?php echo ($_SESSION['menu'] == 4) ? 'is-active' : ''; ?>"
                       href="reports">
                        <i class="u-mr-xsmall fa fa-history"></i>Users Report
                    </a>
                </li>
                <li class="c-menu__item">
                    <a data-turbolinks-replace="replace"
                       class="c-menu__link <?php echo ($_SESSION['menu'] == 5) ? 'is-active' : ''; ?>"
                       href="announcement">
                        <i class="u-mr-xsmall fa fa-bullhorn"></i>Announcement
                    </a>
                </li>
                <li class="c-menu__item">
                    <a data-turbolinks-replace="replace"
                       class="c-menu__link <?php echo ($_SESSION['menu'] == 6) ? 'is-active' : ''; ?>"
                       href="presenters">
                        <i class="u-mr-xsmall fa fa-black-tie"></i>Presenters
                    </a>
                </li>
                <li class="c-menu__item">
                    <a data-turbolinks-replace="replace"
                       class="c-menu__link <?php echo ($_SESSION['menu'] == 7) ? 'is-active' : ''; ?>"
                       href="users-details">
                        <i class="u-mr-xsmall fa fa-phone-square"></i>App Users
                    </a>
                </li>
            </ul>

            <h4 class="c-menu__title">Quick Action</h4>
            <ul>
                <li class="c-menu__item">
                    <a class="c-menu__link is-disabled" href="reports">
                        <i class="fa fa-sticky-note u-text-mute"></i> Reports: <?php echo ($rd_rep==null)?'0':$rd_rep->num_rows; ?>
                    </a>
                </li>
                <li class="c-menu__item">
                    <a class="c-menu__link is-disabled" href="connect">
                        <i class="fa fa-history  u-text-mute"></i> Articles: <?php echo ($rd==null)?'0':$rd->num_rows; ?>
                    </a>
                </li>
                <li class="c-menu__item">
                    <a class="c-menu__link is-disabled" href="users-details">
                        <i class="fa fa-android  u-text-mute"></i> App Users: <?php echo ($rd_app==null)?'0':$rd_app->num_rows; ?>
                    </a>
                </li>
            </ul>
            <!--
            <ul>
                <li class="c-menu__item">
                    <a class="c-menu__link" href="#">
                        <img src="img/sidebar-icon1.png" class="u-mr-xsmall" style="width: 14px;" alt="Icon 1">Classes
                    </a>
                </li>
                <li class="c-menu__item">
                    <a class="c-menu__link" href="#">
                        <img src="img/sidebar-icon2.png" class="u-mr-xsmall" style="width: 14px;" alt="Icon 2">People
                    </a>
                </li>
                <li class="c-menu__item">
                    <a class="c-menu__link" href="#">
                        <img src="img/sidebar-icon3.png" class="u-mr-xsmall" style="width: 14px;" alt="Icon 3">Networking
                    </a>
                </li>
                <li class="c-menu__item">
                    <a class="c-menu__link" href="#">
                        <img src="img/sidebar-icon4.png" class="u-mr-xsmall" style="width: 14px;" alt="Icon 4">Hi-Skill
                    </a>
                </li>
                <li class="c-menu__item">
                    <a class="c-menu__link" href="#">
                        <img src="img/sidebar-icon5.png" class="u-mr-xsmall" style="width: 14px;" alt="Add icon">Going to Buy
                    </a>
                </li>
                <li class="c-menu__item">
                    <a class="c-menu__link" href="#">
                        <img src="img/sidebar-icon6.png" class="u-mr-xsmall" style="width: 14px;" alt="Add icon">Add New List
                    </a>
                </li>
            </ul>
            -->
            <p class="u-text-small u-mt-large u-text-mute">Druplay Technology</p>
        </aside>
    </div>