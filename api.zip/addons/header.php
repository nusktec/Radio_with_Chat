
<header class="c-navbar u-mb-medium">
    <a class="c-navbar__brand" href="#!">
        <img src="img/logo.png" alt="Dashboard's Logo">
    </a>

    <!-- Navigation items that will be collapes and toggle in small viewports -->
    <nav class="c-nav collapse" id="main-nav">
        <ul class="c-nav__list">
            <li class="c-nav__item">
                <a class="c-nav__link" href="#!">Druplay News</a>
            </li>
            <li class="c-nav__item">
                <a class="c-nav__link" href="#!">Events</a>
            </li>
            <li class="c-nav__item">
                <a class="c-nav__link" href="#!">About us</a>
            </li>
            <li class="c-nav__item">
                <a class="c-nav__link" href="#!">Contact Us</a>
            </li>
            <li class="c-nav__item">
                <div class="c-field c-field--inline has-icon-right u-hidden-up@tablet">
                            <span class="c-field__icon">
                                <i class="fa fa-search"></i>
                            </span>

                    <label class="u-hidden-visually" for="navbar-search-small">Search</label>
                    <input class="c-input" id="navbar-search-small" type="text" placeholder="Search for user">
                </div>
            </li>
        </ul>
    </nav>
    <!-- // Navigation items  -->


    <div class="c-field has-icon-right c-navbar__search u-hidden-down@tablet u-ml-auto u-mr-small">
                <span class="c-field__icon">
                    <i class="fa fa-search"></i>
                </span>
        <label class="u-hidden-visually" for="navbar-search-small">Search</label>
        <input class="c-input" id="navbar-search-small" type="text" placeholder="Search for user">
    </div>

    <div class="c-dropdown dropdown">
        <a class="c-avatar c-avatar--xsmall has-dropdown dropdown-toggle" href="" id="dropdwonMenuAvatar"
           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img class="c-avatar__img" src="LOGOS/<?php echo @$_SESSION['app_id']; ?>" alt="User's Profile Picture">
        </a>

        <div class="c-dropdown__menu dropdown-menu dropdown-menu-right" aria-labelledby="dropdwonMenuAvatar">
            <a class="c-dropdown__item dropdown-item" href="account-settings">Account Settings</a>
            <a class="c-dropdown__item dropdown-item" href="log-out">Sign Out</a>
        </div>
    </div>

    <button class="c-nav-toggle" type="button" data-toggle="collapse" data-target="#main-nav">
        <span class="c-nav-toggle__bar"></span>
        <span class="c-nav-toggle__bar"></span>
        <span class="c-nav-toggle__bar"></span>
    </button><!-- // .c-nav-toggle -->
</header>