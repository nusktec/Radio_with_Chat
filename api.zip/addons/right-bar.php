<?php
//Read from temporal//
$app_id = $_SESSION[DP_APP_ID];
$db = new Db();
$reports = $db->row("select * from `reports` inner join `users` on `reports`.`rep_reporter`=`users`.`phone` where `reports`.`rep_id`='" . $app_id . "' order by `reports`.`rep_finder` desc limit 1");
?>

<!--Right side bar-->
<div class="col-md-5 col-xl-3 u-mb-medium u-hidden-down@tablet">
    <div class="c-project-card u-mb-medium">
        <img class="c-project-card__img" onerror=this.src="img/project-card2.jpg" src="PROFILE_IMG/<?php echo ($reports==null)?'noImage':$reports->phone ?>" alt="About the image">

        <div class="c-project-card__content">
            <div class="c-project-card__head">
                <h4 class="c-project-card__title">Recent Report</h4>
                <p class="c-project-card__info">Submitted: <?php echo ($reports==null)?'No Report':time_elapsed_string($reports->rep_date)." ago" ?></p>
            </div>

            <div class="c-project-card__meta">
                <p>Contents
                    <small class="u-block u-text-mute"><?php echo ($reports==null)?'No Report':substr($reports->rep_desc,0,300)."..." ?></small>
                </p>
            </div>

            <div class="c-project-card__meta">
                <p>From
                    <small class="u-block u-text-mute"><?php echo ($reports==null)?'No Report':$reports->name ?></small>
                </p>
                <p>
                    <a href="reports" data-turbolinks-action="replace" class="c-btn c-btn--fancy u-ml-small u-mr-small u-mb-small">Read More</a>
                </p>
            </div>
        </div>
    </div><!--// .c-profile -->

    <!-- FAQ -->
    <h4 class="u-h6 u-text-bold u-mb-xsmall">Contact Druplay Team</h4>
    <ul>
        <li class="u-mb-xsmall">
            <a class="u-text-dark u-text-small" href="javascript:void(0);">Technical Team</a>
        </li>
        <li class="u-mb-xsmall">
            <a class="u-text-dark u-text-small" href="javascript:void(0);">Marketing Team</a>
        </li>
    </ul>
    <!-- DEVELOPER NOTE
        Modify this component to `c-list`

    <ul>
        <li class="u-mb-xsmall">
            <a class="u-text-dark u-text-small" href="#">How can I connect my bank account?</a>
        </li>

        <li class="u-mb-xsmall">
            <a class="u-text-dark u-text-small" href="#">Why Dashboard doesn’t show any data?</a>
        </li>
        <li class="u-mb-xsmall">
            <a class="u-text-dark u-text-small" href="#">If I change my avatar in one version will it appears in
                next version?</a>
        </li>
    </ul>
    <a class="u-text-small u-color-blue" href="#">Visit FAQ Page</a>
    -->
</div>