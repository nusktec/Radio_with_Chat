<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/16/2018
 * Time: 12:30 AM
 */
$r = new DateTime();
echo $r->getTimestamp();