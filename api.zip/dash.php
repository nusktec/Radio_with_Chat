<?php
require('lib/config.php');
require('assembly.php');
check_login();
page_identity(1, "Account");
?>
<!doctype html>
<html lang="en-us">
<?php include 'header-js.php' ?>
<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->
<?php include 'addons/header.php' ?>

<div class="container">
    <?php include 'addons/left-bar.php' ?>
    <!--Left side bar-->

    <div id="pages" v-html="htmldata.raw" class="col-md-7 col-xl-6">
        <?php
        //Read from temporal//
        $email = $_SESSION[DP_ACCOUNT];
        $db = new Db();
        $rd = $db->row("select * from `account` where `app_email`='" . $email . "' LIMIT 1");
        //fetch slider
        $slider = $db->query("select * from `sliders` where `slider_id`='" . $rd->app_id . "' order by `slider_finder` desc limit 50");
        if ($slider->num_rows == 0) {
            $slider = array();
        }
        ?>
        <main>
            <div class="c-card u-p-medium u-text-small u-mb-small">
                <h6 class="u-text-bold">General Info</h6>

                <dl class="u-flex u-pv-small u-border-bottom">
                    <dt class="u-width-25">Name</dt>
                    <dd><?php echo $rd->app_name; ?></dd>
                </dl>

                <dl class="u-flex u-pv-small u-border-bottom">
                    <dt class="u-width-25">Email</dt>
                    <dd><?php echo $rd->app_email; ?></dd>
                </dl>

                <dl class="u-flex u-pv-small u-border-bottom">
                    <dt class="u-width-25">Avatar
                        <small class="u-block u-text-mute">JPG, max. 500KB</small>
                    </dt>

                    <dd>
                        <a class="c-avatar c-avatar--small" href="#">
                            <img class="c-avatar__img" src="LOGOS/<?php echo $rd->app_id; ?>" alt="App Icon">
                        </a>
                    </dd>


                </dl>

                <dl class="u-flex u-pt-small">
                    <dt class="u-width-25">Address</dt>
                    <dd><?php echo $rd->app_country; ?> (<?php echo $rd->app_address; ?>)</dd>
                </dl>
            </div>

            <div class="c-card u-p-medium u-mb-medium">
                <h6 class="u-text-bold">Sliders / Adverts</h6>
                <?php if (@$slider->num_rows < 50) {
                    include 'slider_uploader_class.php';
                } else {
                    echo "<p style='color: red'>Maximum upload is 50</p>";
                } ?>
                <div class="c-card u-p-medium c-messages" style="max-height: 400px">
                    <?php
                    foreach ($slider as $key => $value) {
                        $ls = (object)$value;
                        ?>
                        <div class="c-fileitem c-message">
                            <div class="c-fileitem__content u-mr-small">
                                <a href="<?php echo $ls->slider_link ?>" target="_blank">
                                    <div title="<?php echo $ls->slider_desc ?>" class="c-fileitem__img">
                                        <img src="<?php echo PRO_APPS . '/' . $ls->slider_id . '/sliders/' . $ls->slider_finder ?>"
                                             alt="Slider">
                                    </div>
                                </a>
                                <p class="u-text-small u-text-mute">
                                    <?php echo substr($ls->slider_title, 0, 30) . "..."; ?>
                                </p>
                            </div>
                            <div class="">
                                <small class="u-text-small u-text-mute" style="margin-right: 5px;">
                                    <?php echo time_elapsed_string($ls->slider_date); ?>
                                </small>
                                <a class="" type="button" class="c-btn c-btn--secondary" data-toggle="modal"
                                   data-target="#<?php echo $ls->slider_finder ?>">
                                    <i class="fa fa-eye u-color-twitter c-btn c-btn--secondary"></i>
                                </a>

                                <a class="" href="javascript:void(0);"
                                   onclick="removeSlider('<?php echo $ls->slider_finder ?>','<?php echo $ls->slider_id ?>')">
                                    <i class="fa fa-remove u-color-danger c-btn c-btn--secondary"></i>
                                </a>
                            </div>
                        </div><!-- // .c-fileitem -->

                        <!-- Modal -->
                        <div class="c-modal modal fade" id="<?php echo $ls->slider_finder ?>" tabindex="-1" role="dialog"
                             aria-labelledby="myModal3">
                            <div class="c-modal__dialog modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="c-card u-p-medium u-mh-auto" style="max-width:500px;">
                                        <h3><?php echo $ls->slider_title ?></h3>
                                        <div class="c-project__img">
                                            <img onerror=this.src="img/avatar6-72.jpg"
                                                 src="<?php echo PRO_APPS . '/' . $ls->slider_id . '/' . 'sliders/' . $ls->slider_finder ?>"
                                                 alt="Advert">
                                        </div>
                                        <p class="u-text-mute u-mb-small"><?php echo $ls->slider_desc ?></p>
                                        <button class="c-btn c-btn--info" data-dismiss="modal">
                                            Close
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>

                </div>
            </div>
            <!-- DEV NOTE:
                Remove `c-settings` and replace it with flex utilities
             -->

    </div>

    <!--Right Bar-->
    <?php include 'addons/right-bar.php' ?>

</div>
<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>
    function removeSlider(f, v) {
        var result = confirm("Want to remove the selected slider ?");
        if (result) {
            //Logic to delete the item

            NProgress.start();
            //start sending info
            $.ajax({
                headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
                type: "POST",
                url: "xapi",
                data: {finder: f, id: v, act: 'remove-slider'},
                success: function (data) {
                    var obj = JSON.parse(data);
                    if (obj.status) {
                        Turbolinks.visit('dash');
                    }
                    Toast("Slider not removed");
                    NProgress.done();
                }
            });
            return false;

        }
    }
</script>
</body>
</html>