<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/13/2018
 * Time: 7:49 AM
 */
//setup login command
require ('lib/config.php');
//force login
check_login();
header("location: dash");