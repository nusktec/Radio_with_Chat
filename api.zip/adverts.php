<?php
require('lib/config.php');
page_identity(8, 'Adverts');
?>
<!doctype html>
<html lang="en-us">
<?php require('header-js.php') ?>
<style>
    * {
        -webkit-user-select: none;
    }
</style>
<?php
$phone = (@$_GET['phone'] == null) ? @$_POST['phone'] : @$_GET['phone'];
$app_id = (@$_GET['app_id'] == null) ? @$_POST['app_id'] : @$_GET['app_id'];

$db = new Db();

//read from database
$adverts = $db->query("select * from `sliders` where `slider_id`='$app_id' order by `slider_finder` desc");

if ($adverts->num_rows == 0) {
    ?>
    <div class="container  o-page--center u-text-center">
        <i class="fa fa-file" style="font-size: 48px"></i>
        <p class="u-color-danger">No Adverts !</p>
        <br/>
        <a href="adverts?app_id=<?php echo $app_id; ?>" class="c-btn c-btn--secondary">Refresh</a>
    </div>
    <?php
    return;
}
?>
<body>
<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience and security.</p>
<![endif]-->

<div class="container">
    <div class="row">
        <?php
        foreach ($adverts

        as $key => $value) {
        $ad = (object)$value;
        ?>
        <div class="u-mt-small">
            <div class="c-project">
                <div class="c-project__img">
                    <img onerror=this.src="img/avatar6-72.jpg"
                         src="<?php echo PRO_APPS . '/' . $ad->slider_id . '/' . 'sliders/' . $ad->slider_finder ?>"
                         alt="Advert">
                </div>

                <h3 class="c-project__title"><?php echo $ad->slider_title; ?>
                    <span class="c-project__status">Last updated: <span
                                class="u-text-bold"><?php echo time_elapsed_string($ad->slider_date); ?></span></span>
                </h3>

                <div class="c-project__team">
                    <button type="button" class="c-btn c-btn--secondary" data-toggle="modal"
                       data-target="#<?php echo $ad->slider_finder; ?>" class="c-btn c-btn--secondary c-btn--fullwidth"
                       aria-label="Read More" href="javascript:void(0)">
                        <i class="fa fa-eye"></i> Read More
                    </button>

                    <!-- Modal -->
                    <div class="c-modal modal fade" id="<?php echo $ad->slider_finder; ?>" tabindex="-1" role="dialog"
                         aria-labelledby="<?php echo $ad->slider_finder; ?>" aria-hidden="true" style="display: none;">
                        <div class="c-modal__dialog modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="c-card u-p-medium u-mh-auto" style="max-width:500px;">
                                    <h3><?php echo $ad->slider_title; ?></h3>
                                    <p class="u-text-mute u-mb-small"><?php echo $ad->slider_desc; ?></p>
                                    <button class="c-btn c-btn--info" data-dismiss="modal">
                                        Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div><!-- // .c-project -->
    </div>
    <?php
    }
    ?>
</div>
</div><!-- // .row -->
</div><!-- // .container -->

<script src="js/jquery.min.js"></script>
<script src="js/main.min.js"></script>
<script src="js/footer.js"></script>
<script>

</script>
</body>
</html>