<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/21/2018
 * Time: 9:58 PM
 */
?>
<button class="c-btn c-btn--danger c-btn--fullwidth" href="javascript:void(0)" data-toggle="modal"
   data-target="#reports_frame">
    <i class="fa fa-bullhorn"></i> Send Notification
</button>
<!-- Modal -->
<div class="c-modal c-modal--xsmall modal fade" id="reports_frame" tabindex="-1" role="dialog" aria-labelledby="modal7"
     data-backdrop="static" style="display: none;" aria-hidden="true">
    <div class="c-modal__dialog modal-dialog" role="document">
        <div class="c-modal__content">

            <div class="c-modal__header">
                <h3 class="c-modal__title">Druplay Announcement Creator</h3>

                <span class="c-modal__close" data-dismiss="modal" aria-label="Close">
                                        <i class="fa fa-close"></i>
                                    </span>
            </div>

            <div class="c-modal__body">
                <div class="c-field u-mb-xsmall" data-select2-id="24">
                    <label class="c-field__label" for="select12">Instant Announcement</label>
                </div>

                <form enctype="multipart/form-data" id="uploaderForm" method="post" action="xapi" onsubmit="return sendNotification()">
                    <div class="c-field u-mb-xsmall">
                        <label class="c-field__label" for="link">Announcement Title</label>
                        <input id="title" name="title" value="" class="c-input" type="text" placeholder="Announcement Title">
                    </div>
                    <div class="c-field u-mb-xsmall">
                        <label class="c-field__label" for="desc">Description / Content</label>
                        <textarea placeholder="500 Max" maxlength="1000" required="required" class="c-input" id="desc" name="desc"></textarea>
                    </div>
                    <button type="submit" class="c-btn c-btn--success c-btn--fullwidth">
                        Send Now
                    </button>
                </form>

            </div>

        </div>
    </div>
</div>
<script>
    function sendNotification() {
        //NProgress.start();
        //start sending info
//        $.ajax({
//            headers: {nsckey: "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj=="},
//            type: "POST",
//            url: "xapi",
//            data: $('#uploaderForm').serialize(),
//            success: function (data) {
//                var obj = JSON.parse(data);
//                if (obj.status) {
//                    Turbolinks.visit('dash');
//                }
//                Toast("Slider not added");
//                NProgress.done();
//            }
//        });
        Toast('Notification features not available in this version...');
        return false;
    }

    //load image
    function readImage(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#preview')
                    .attr('src', e.target.result)
                    .height(200);
            };
            reader.readAsDataURL(input.files[0]);
//
//            var file = input.files[0];
//            var reader2 = new FileReader();
//            reader2.onloadend = function() {
//                $('#keepimg').val(reader2.result);
//            }
//            reader2.readAsDataURL(file);
        }
    }
    //convert it
</script>
