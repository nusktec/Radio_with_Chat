<?php
/**
 * Created by PhpStorm.
 * User: NSC
 * Date: 10/13/2018
 * Time: 10:51 AM
 */
error_reporting(0);
$headers = getallheaders()['nsckey'];
if (empty($_POST['uploader'])) {
    if ($headers != "hdfkjalfADJKHEJWHWJH2353131mjnxczcjlcsjddjisdj==") {
        echo json_encode(array("status" => false, "message" => "invalid token"));
        exit(0);
    }
}

require('lib/config.php');

$action = $_POST['act'];
switch ($action) {
    case 'sign-in':
        signIn();
        break;
    case 'change-pass':
        changePass();
        break;
    case 'apply-settings':
        applySettings();
        break;
    case 'insert-slider':
        insertSlider();
        break;
    case 'remove-slider':
        removeSlider();
        break;
    case 'remove-pres':
        removePress();
        break;
    case 'insert-presenter':
        insertPresenter();
        break;
    case 'insert-article':
        insertArticle();
        break;
    case 'remove-article':
        removeArticle();
        break;
    case 'mark-report':
        markReport();
        break;
    case 'delete-report':
        deleteReport();
        break;
    case 'load-article':
        loadArticle();
        break;
    default:
        exit(0);
}

//load-article
function loadArticle()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>Not a valid query to perform task</p>", array());
            return;
        }
    }
    $id = $_POST['id'];
    $finder = $_POST['finder'];
    $db = new Db();
    $rd = $db->query("select * from `connects` inner join `users` on `users`.`phone`=`connects`.`con_user` where `connects`.`con_id`='$id' and `connects`.`con_finder`='$finder' order by `connects`.`con_finder` desc");
    $res = array();
    $rd2 = $rd->fetch_all(MYSQLI_ASSOC);
    foreach ($rd2 as $key => $val) {
        $tmp = $val;
        $tmp['time'] = time_elapsed_string($val['con_date']) . " ago";
        $tmp['image'] = "PROFILE_IMG/" . $val['con_user'] . "";
        array_push($res, $tmp);
    }
    if ($rd->num_rows > 0) {
        echo druplay_output2(true, "<p style='color: #3def67'>Article loaded</p>", $res);
    } else {
        echo druplay_output2(false, "<p style='color: #3ae862'>Failed to load articles</p>", array());
    }
}

//delete report
function deleteReport()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>Not a valid query to perform task</p>", array());
            return;
        }
    }
    $db = new Db();
    //proceed to file deleting...
    $upd = $db->delete("reports", array("rep_finder" => $_POST['finder'], "rep_id" => $_POST['id']));
    if ($upd) {
        echo druplay_output(true, "<p style='color: #3fff6b'>Report was deleted</p>", array());
        return;
    }
    echo druplay_output(false, "<p style='color: #ff0017'>An error was encountered</p>", array());
}

//Mark report as read
function markReport()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>Not a valid query to perform task</p>", array());
            return;
        }
    }
    $db = new Db();
    //proceed to file deleting...
    $upd = $db->update("reports", array("rep_read" => true), array("rep_finder" => $_POST['finder'], "rep_id" => $_POST['id']));
    if ($upd) {
        echo druplay_output(true, "<p style='color: #3fff6b'>Report was marked as read</p>", array());
        return;
    }
    echo druplay_output(false, "<p style='color: #ff0017'>An error was encountered</p>", array());
}

//insert articles
function insertArticle()
{
    global $PRO_ARTICLE;
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            header("location: connect");
            echo druplay_output(false, "<p style='color: #ff2b56'>Adding article failed due to empty field</p>", array());
            return;
        }
    }
    $db = new Db();
    $date = new DateTime();
    $date = $date->getTimestamp();
    $ins = $db->insert("articles", array('art_id' => $_SESSION[DP_APP_ID], 'art_desc' => $_POST['desc'], 'art_title' => $_POST['title'], 'art_date' => $date, 'art_pres'=>$_POST['presenter']));
    if ($ins['body']) {
        //save slider image
        $name = (string)$ins['body'];
        $img = $_FILES['art_img'];
        if (move_uploaded_file($img['tmp_name'], $PRO_ARTICLE . "/" . $name)) {
            header("location: connect");
            echo druplay_output(true, "<p style='color: #32c80c'>Article added</p>", array());
            return;
        }
    }
    header("location: connect");
    echo druplay_output(false, "<p style='color: #ff2b56'>Could not add article</p>", array());
}

//remove article
function removeArticle()
{
    global $PRO_ARTICLE;
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>Unable to remove slider</p>", array());
            return;
        }
    }
    $db = new Db();
    //proceed to file deleting...
    if (unlink($PRO_ARTICLE . '/' . $_POST['finder'])) {
        $del = $db->delete('articles', array('art_finder' => $_POST['finder'], 'art_id' => $_POST['id']));
        $db->delete('connects', array('con_finder' => $_POST['finder'], 'con_id' => $_POST['id']));
        if ($del) {
            echo druplay_output(true, "<p style='color: #3fff6b'>Article removed</p>", array());
            return;
        }
    } else {
        $del = $db->delete('articles', array('art_finder' => $_POST['finder'], 'art_id' => $_POST['id']));
        $db->delete('connects', array('con_finder' => $_POST['finder'], 'con_id' => $_POST['id']));
        if ($del) {
            echo druplay_output(true, "<p style='color: #3fff6b'>Article removed</p>", array());
            return;
        }
    }
    echo druplay_output(false, "<p style='color: #ff0017'>An error was encountered</p>", array());
}

//remove presenter
function removePress()
{
    global $PRO_PRESENTER;
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>Unable to remove presenter</p>", array());
            return;
        }
    }
    $db = new Db();
    //proceed to file deleting...
    if (unlink($PRO_PRESENTER . '/' . $_POST['finder'])) {
        $del = $db->delete('presenters', array('pres_finder' => $_POST['finder'], 'pres_id' => $_POST['id']));
        if ($del) {
            echo druplay_output(true, "<p style='color: #3fff6b'>Presenter removed</p>", array());
            return;
        }
    } else {
        $del = $db->delete('presenters', array('pres_finder' => $_POST['finder'], 'pres_id' => $_POST['id']));
        if ($del) {
            echo druplay_output(true, "<p style='color: #3fff6b'>Presenter removed</p>", array());
            return;
        }
    }
    echo druplay_output(false, "<p style='color: #ff0017'>Error was encountered</p>", array());
}

//remove slider
function removeSlider()
{
    global $PRO_SLIDER;
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>Unable to remove slider</p>", array());
            return;
        }
    }
    $db = new Db();
    //proceed to file deleting...
    if (unlink($PRO_SLIDER . '/' . $_POST['finder'])) {
        $del = $db->delete('sliders', array('slider_finder' => $_POST['finder'], 'slider_id' => $_POST['id']));
        if ($del) {
            echo druplay_output(true, "<p style='color: #3fff6b'>Slider removed</p>", array());
            return;
        }
    } else {
        $del = $db->delete('sliders', array('slider_finder' => $_POST['finder'], 'slider_id' => $_POST['id']));
        if ($del) {
            echo druplay_output(true, "<p style='color: #3fff6b'>Slider removed</p>", array());
            return;
        }
    }
    echo druplay_output(false, "<p style='color: #ff0017'>Error was encountered</p>", array());
}

//insert slider in db
function insertPresenter()
{
    global $PRO_PRESENTER;
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>Adding presenter failed due to empty field</p>", array());
            return;
        }
    }
    $db = new Db();
    $ins = $db->insert("presenters", array('pres_id' => $_SESSION[DP_APP_ID], 'pres_name' => $_POST['name'], 'pres_program' => $_POST['program']));
    if ($ins['body']) {
        //save slider image
        $name = (string)$ins['body'];
        $img = $_FILES['image'];
        if (move_uploaded_file($img['tmp_name'], $PRO_PRESENTER . "/" . $name)) {
            header("location: presenters");
            echo druplay_output(true, "<p style='color: #32c80c'>Presenter added</p>", array());
            return;
        }
    }
    header("location: presenters");
    echo druplay_output(false, "<p style='color: #ff2b56'>Could not add presenters</p>", array());
}

//insert slider in db
function insertSlider()
{
    global $PRO_SLIDER;
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>Adding slider failed due to empty field</p>", array());
            return;
        }
    }
    $db = new Db();
    $date = new DateTime();
    $date = $date->getTimestamp();
    $ins = $db->insert("sliders", array('slider_id' => $_SESSION[DP_APP_ID], 'slider_desc' => $_POST['desc'],'slider_title' => $_POST['title'], 'slider_link' => $_POST['link'], 'slider_date' => $date));
    if ($ins['body']) {
        //save slider image
        $name = (string)$ins['body'];
        $img = $_FILES['slider'];
        if (move_uploaded_file($img['tmp_name'], $PRO_SLIDER . "/" . $name)) {
            header("location: dash");
            echo druplay_output(true, "<p style='color: #32c80c'>Slider added</p>", array());
            return;
        }
    }
    header("location: dash");
    echo druplay_output(false, "<p style='color: #ff2b56'>Could not add slider</p>", array());
}

//apply settings
function applySettings()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>One of the field is empty</p>", array());
            return;
        }
    }
    $db = new Db();
    switch ($_POST['role']) {
        case 'auc':
            $db->query("update `settings` set `set_auc`=" . (int)$_POST['value'] . " where `set_id`='" . $_SESSION[DP_APP_ID] . "'");
            echo druplay_output(true, "<p style='color: #40ff6b'>Saved</p>", array());
            break;
        case 'aup':
            $db->query("update `settings` set `set_aup`=" . (int)$_POST['value'] . " where `set_id`='" . $_SESSION[DP_APP_ID] . "'");
            echo druplay_output(true, "<p style='color: #1eff48'>Saved</p>", array());
            break;
        case 'asl':
            $db->query("update `settings` set `set_asl`='" . $_POST['value'] . "' where `set_id`='" . $_SESSION[DP_APP_ID] . "'");
            echo druplay_output(true, "<p style='color: #1eff48'>Saved</p>", array());
            break;
        case 'aasl':
            $db->query("update `settings` set `set_aasl`='" . $_POST['value'] . "' where `set_id`='" . $_SESSION[DP_APP_ID] . "'");
            echo druplay_output(true, "<p style='color: #1eff48'>Saved</p>", array());
            break;
        default:
            exit(0);
    }

}

//Change password
function changePass()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>One of the field is empty</p>", array());
            return;
        }
    }
    if ($_POST['pn'] != $_POST['pc']) {
        echo druplay_output(false, "<p style='color: #ff2b56'>Password not the same</p>", array());
        return;
    }
    //start validating lkey
    $db = new Db();
    $pass = druplay_password($_POST['pn']);
    $pass_old = druplay_password($_POST['po']);
    $email = $_SESSION[DP_ACCOUNT];
    $upd = $db->update('account', array('app_pass' => $pass), array('app_pass' => $pass_old, 'app_email' => $email));
    if ($upd) {
        echo druplay_output(true, "<p style='color: #4567ff'>Password changed !</p>", array());
        return;
    }
    echo druplay_output(false, "<p style='color: #ff2b56'>Unable to change password, sign out and try again</p>", array());
}

//Login systems
function signIn()
{
    foreach ($_POST as $item => $value) {
        if (empty($value)) {
            echo druplay_output(false, "<p style='color: #ff2b56'>" . ucfirst($item) . " is empty</p>", array());
            return;
        }
    }
    //start validating lkey
    $db = new Db();
    $email = $_POST['email'];
    $pass = druplay_password($_POST['password']);
    $rd = $db->row("select * from `account` where `app_email`='$email' and `app_pass`='$pass' limit 1");
    if ($rd) {
        //create settings space
        if (!$db->row("select * from `settings` where `set_id`='" . $rd->app_id . "' limit 1")) {
            $db->insert('settings', array('set_id' => $rd->app_id));
        }
        if ($rd->app_status == 0) {
            echo druplay_output(false, "<p style='color: red'>Your account has been expired, please renew your license key</p>", (array)$rd);
            return;
        }
        if ($rd->app_status == 2) {
            echo druplay_output(false, "<p style='color: blue'>Your account has not been activated, please contact druplay</p>", (array)$rd);
            return;
        }
        if ($rd->app_status == 1) {
            session_start();
            $_SESSION[DP_ACCOUNT] = $email;
            $_SESSION[DP_PASSWORD] = $rd->app_pass;
            $_SESSION[DP_APP_ID] = $rd->app_id;
            //mount default folder
            echo druplay_output(true, "<p style='color: #10b200'>Welcome, Please wait...</p>", array());
            return;
        }
    }
    echo druplay_output(false, "<p style='color: #ff0015'>Invalid email or password</p>", array());
}